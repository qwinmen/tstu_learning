﻿namespace MapTech
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.styleManager1 = new DevComponents.DotNetBar.StyleManager(this.components);
            this.superTabControl_КонтейнерВкладок = new DevComponents.DotNetBar.TabControl();
            this.superTabControlPanel1_Оптимизация = new DevComponents.DotNetBar.TabControlPanel();
            this.superTabItem_Оптимизация = new DevComponents.DotNetBar.TabItem(this.components);
            this.superTabControlPanelBody_А = new DevComponents.DotNetBar.TabControlPanel();
            this.reflectionLabel1_НетКомпонентов = new DevComponents.DotNetBar.Controls.ReflectionLabel();
            this.groupPanel1_КритерииАвтоВыбора = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.radioButton1_НечеткоеПравило = new System.Windows.Forms.RadioButton();
            this.radioButton1_МаксимальнаяСтоимость = new System.Windows.Forms.RadioButton();
            this.advTree1 = new DevComponents.AdvTree.AdvTree();
            this.nodeConnector1 = new DevComponents.AdvTree.NodeConnector();
            this.elementStyle1 = new DevComponents.DotNetBar.ElementStyle();
            this.groupPanel_РежимВыбора = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.itemPanel_СемьЭлементов = new DevComponents.DotNetBar.ItemPanel();
            this.buttonItem1_Агломератор = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem2_дробилка = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem3_Экструдер = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem4_Контейнер = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem5_Конвеер = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem6_Магнит = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem7_Пескосушилка = new DevComponents.DotNetBar.ButtonItem();
            this.switchButton_РучнойАвто = new DevComponents.DotNetBar.Controls.SwitchButton();
            this.flowLayoutPanel_ВизуальныйКонтейнер = new System.Windows.Forms.FlowLayoutPanel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.очиститьПолеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ПечатьtoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.superTabItemHead_А = new DevComponents.DotNetBar.TabItem(this.components);
            this.superTabControlPanelBody_Б = new DevComponents.DotNetBar.TabControlPanel();
            this.superTabControl1_АБОТ = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel1_ПТМ = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.advTree2_ТаблОпераций = new DevComponents.AdvTree.AdvTree();
            this.columnHeader1 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader2 = new DevComponents.AdvTree.ColumnHeader();
            this.columnHeader3 = new DevComponents.AdvTree.ColumnHeader();
            this.nodeConnector2 = new DevComponents.AdvTree.NodeConnector();
            this.elementStyle2 = new DevComponents.DotNetBar.ElementStyle();
            this.superTabItem1_ПТМ = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel4_Т = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.label_СтрокаСостояния_Т = new System.Windows.Forms.Label();
            this.textBoxX_Т = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.superTabItem4_Т = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel3_О = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.label_CтрокаСостояний_О = new System.Windows.Forms.Label();
            this.textBoxX1_O = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.superTabItem3_О = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel2_Б = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.label_СтрокаСостояний_Б = new System.Windows.Forms.Label();
            this.integerInput_ОП = new DevComponents.Editors.IntegerInput();
            this.integerInput_ЕН = new DevComponents.Editors.IntegerInput();
            this.integerInput_КОИД = new DevComponents.Editors.IntegerInput();
            this.integerInput__КР = new DevComponents.Editors.IntegerInput();
            this.panel1_ДляНастроекСправо = new System.Windows.Forms.Panel();
            this.textBoxX_Тшт = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_Тпз = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_Кшт = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_УТ = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_Р = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_Проф = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_СМ = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_Код = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.superTabItem2_Б = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel1_А = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.textBoxX6_ДокОхранаТруда = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_КодОперации = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_НОперации = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_РМесто = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_Участок = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX_Цех = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.label_СтрокаСостояний_А = new System.Windows.Forms.Label();
            this.superTabItem1_А = new DevComponents.DotNetBar.SuperTabItem();
            this.panelEx1_Меню = new DevComponents.DotNetBar.PanelEx();
            this.buttonX6_Подтвердить = new DevComponents.DotNetBar.ButtonX();
            this.buttonX_ТаблицаОперацийПоказать = new DevComponents.DotNetBar.ButtonX();
            this.buttonX2 = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1_Т = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1_О = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1_Б = new DevComponents.DotNetBar.ButtonX();
            this.buttonX1_А = new DevComponents.DotNetBar.ButtonX();
            this.superTabItemHead_Б = new DevComponents.DotNetBar.TabItem(this.components);
            this.superTabControlPanel1_Help = new DevComponents.DotNetBar.TabControlPanel();
            this.buttonX1_NextSlideHelp = new DevComponents.DotNetBar.ButtonX();
            this.pageSlider1 = new DevComponents.DotNetBar.Controls.PageSlider();
            this.pageSliderPage1_ПроизводственнаяЛиния = new DevComponents.DotNetBar.Controls.PageSliderPage();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.reflectionImage1_Рис1 = new DevComponents.DotNetBar.Controls.ReflectionImage();
            this.pageSliderPage2_Проектирование = new DevComponents.DotNetBar.Controls.PageSliderPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.reflectionImage1_Рис2 = new DevComponents.DotNetBar.Controls.ReflectionImage();
            this.pageSliderPage3_МаршрутнаяКарта = new DevComponents.DotNetBar.Controls.PageSliderPage();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.reflectionImage1_Рис3 = new DevComponents.DotNetBar.Controls.ReflectionImage();
            this.pageSliderPage4_Оптимизация = new DevComponents.DotNetBar.Controls.PageSliderPage();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.reflectionImage1_Рис4 = new DevComponents.DotNetBar.Controls.ReflectionImage();
            this.superTabItem1_HelpTab = new DevComponents.DotNetBar.TabItem(this.components);
            this.superTabControlPanelBody_В = new DevComponents.DotNetBar.TabControlPanel();
            this.reoGridControl_МаршрутнаяКарта = new unvell.ReoGrid.ReoGridControl();
            this.superTabItemHead_В = new DevComponents.DotNetBar.TabItem(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.linkLabel_Help = new System.Windows.Forms.LinkLabel();
            this.ucOptimizm1 = new TestFile.UCOptimizm();
            this.ucParametrs1 = new TestFile.UCParametrs();
            this.ucNeLogik1 = new Ne4etkaLogika.UCNeLogik();
            this.ucТехОснастка1 = new TestFile.UCТехОснастка();
            this.ucКодУсловийТруда1 = new TestFile.UCКодУсловийТруда();
            this.ucРазрядРаботы1 = new TestFile.UCРазрядРаботы();
            this.ucСтепеньМеханизац_2 = new TestFile.UCСтепеньМеханизац();
            this.ucКодПроф_3 = new TestFile.UCКодПроф();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_КонтейнерВкладок)).BeginInit();
            this.superTabControl_КонтейнерВкладок.SuspendLayout();
            this.superTabControlPanel1_Оптимизация.SuspendLayout();
            this.superTabControlPanelBody_А.SuspendLayout();
            this.groupPanel1_КритерииАвтоВыбора.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.advTree1)).BeginInit();
            this.groupPanel_РежимВыбора.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.superTabControlPanelBody_Б.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1_АБОТ)).BeginInit();
            this.superTabControl1_АБОТ.SuspendLayout();
            this.superTabControlPanel1_ПТМ.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.advTree2_ТаблОпераций)).BeginInit();
            this.superTabControlPanel4_Т.SuspendLayout();
            this.superTabControlPanel3_О.SuspendLayout();
            this.superTabControlPanel2_Б.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.integerInput_ОП)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.integerInput_ЕН)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.integerInput_КОИД)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.integerInput__КР)).BeginInit();
            this.panel1_ДляНастроекСправо.SuspendLayout();
            this.superTabControlPanel1_А.SuspendLayout();
            this.panelEx1_Меню.SuspendLayout();
            this.superTabControlPanel1_Help.SuspendLayout();
            this.pageSlider1.SuspendLayout();
            this.pageSliderPage1_ПроизводственнаяЛиния.SuspendLayout();
            this.pageSliderPage2_Проектирование.SuspendLayout();
            this.pageSliderPage3_МаршрутнаяКарта.SuspendLayout();
            this.pageSliderPage4_Оптимизация.SuspendLayout();
            this.superTabControlPanelBody_В.SuspendLayout();
            this.SuspendLayout();
            // 
            // styleManager1
            // 
            this.styleManager1.ManagerStyle = DevComponents.DotNetBar.eStyle.Metro;
            this.styleManager1.MetroColorParameters = new DevComponents.DotNetBar.Metro.ColorTables.MetroColorGeneratorParameters(System.Drawing.Color.White, System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(87)))), ((int)(((byte)(154))))));
            // 
            // superTabControl_КонтейнерВкладок
            // 
            this.superTabControl_КонтейнерВкладок.BackColor = System.Drawing.Color.White;
            this.superTabControl_КонтейнерВкладок.CanReorderTabs = true;
            this.superTabControl_КонтейнерВкладок.ColorScheme.TabBackground = System.Drawing.Color.White;
            this.superTabControl_КонтейнерВкладок.ColorScheme.TabBackground2 = System.Drawing.Color.Empty;
            this.superTabControl_КонтейнерВкладок.ColorScheme.TabBorder = System.Drawing.Color.Black;
            this.superTabControl_КонтейнерВкладок.ColorScheme.TabItemBackground = System.Drawing.Color.Black;
            this.superTabControl_КонтейнерВкладок.ColorScheme.TabItemBackground2 = System.Drawing.Color.Black;
            this.superTabControl_КонтейнерВкладок.ColorScheme.TabItemBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 1F)});
            this.superTabControl_КонтейнерВкладок.ColorScheme.TabItemHotBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 1F)});
            this.superTabControl_КонтейнерВкладок.ColorScheme.TabItemSelectedBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 1F)});
            this.superTabControl_КонтейнерВкладок.Controls.Add(this.superTabControlPanel1_Оптимизация);
            this.superTabControl_КонтейнерВкладок.Controls.Add(this.superTabControlPanelBody_А);
            this.superTabControl_КонтейнерВкладок.Controls.Add(this.superTabControlPanelBody_Б);
            this.superTabControl_КонтейнерВкладок.Controls.Add(this.superTabControlPanel1_Help);
            this.superTabControl_КонтейнерВкладок.Controls.Add(this.superTabControlPanelBody_В);
            this.superTabControl_КонтейнерВкладок.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControl_КонтейнерВкладок.ForeColor = System.Drawing.Color.Black;
            this.superTabControl_КонтейнерВкладок.Location = new System.Drawing.Point(0, 0);
            this.superTabControl_КонтейнерВкладок.Name = "superTabControl_КонтейнерВкладок";
            this.superTabControl_КонтейнерВкладок.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.superTabControl_КонтейнерВкладок.SelectedTabIndex = 0;
            this.superTabControl_КонтейнерВкладок.ShowFocusRectangle = false;
            this.superTabControl_КонтейнерВкладок.Size = new System.Drawing.Size(1020, 463);
            this.superTabControl_КонтейнерВкладок.Style = DevComponents.DotNetBar.eTabStripStyle.Office2007Document;
            this.superTabControl_КонтейнерВкладок.TabIndex = 0;
            this.superTabControl_КонтейнерВкладок.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.superTabControl_КонтейнерВкладок.Tabs.Add(this.superTabItemHead_А);
            this.superTabControl_КонтейнерВкладок.Tabs.Add(this.superTabItemHead_Б);
            this.superTabControl_КонтейнерВкладок.Tabs.Add(this.superTabItemHead_В);
            this.superTabControl_КонтейнерВкладок.Tabs.Add(this.superTabItem_Оптимизация);
            this.superTabControl_КонтейнерВкладок.Tabs.Add(this.superTabItem1_HelpTab);
            // 
            // superTabControlPanel1_Оптимизация
            // 
            this.superTabControlPanel1_Оптимизация.Controls.Add(this.ucOptimizm1);
            this.superTabControlPanel1_Оптимизация.Controls.Add(this.ucParametrs1);
            this.superTabControlPanel1_Оптимизация.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1_Оптимизация.Location = new System.Drawing.Point(0, 22);
            this.superTabControlPanel1_Оптимизация.Name = "superTabControlPanel1_Оптимизация";
            this.superTabControlPanel1_Оптимизация.Padding = new System.Windows.Forms.Padding(1);
            this.superTabControlPanel1_Оптимизация.Size = new System.Drawing.Size(1020, 441);
            this.superTabControlPanel1_Оптимизация.Style.BackColor1.Color = System.Drawing.Color.White;
            this.superTabControlPanel1_Оптимизация.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.superTabControlPanel1_Оптимизация.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(211)))), ((int)(((byte)(211)))));
            this.superTabControlPanel1_Оптимизация.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.superTabControlPanel1_Оптимизация.Style.GradientAngle = 90;
            this.superTabControlPanel1_Оптимизация.TabIndex = 0;
            this.superTabControlPanel1_Оптимизация.TabItem = this.superTabItem_Оптимизация;
            // 
            // superTabItem_Оптимизация
            // 
            this.superTabItem_Оптимизация.AttachedControl = this.superTabControlPanel1_Оптимизация;
            this.superTabItem_Оптимизация.Name = "superTabItem_Оптимизация";
            this.superTabItem_Оптимизация.Text = "Оптимизация";
            this.superTabItem_Оптимизация.Click += new System.EventHandler(this.superTabItem_Оптимизация_Click);
            // 
            // superTabControlPanelBody_А
            // 
            this.superTabControlPanelBody_А.Controls.Add(this.reflectionLabel1_НетКомпонентов);
            this.superTabControlPanelBody_А.Controls.Add(this.groupPanel1_КритерииАвтоВыбора);
            this.superTabControlPanelBody_А.Controls.Add(this.advTree1);
            this.superTabControlPanelBody_А.Controls.Add(this.groupPanel_РежимВыбора);
            this.superTabControlPanelBody_А.Controls.Add(this.flowLayoutPanel_ВизуальныйКонтейнер);
            this.superTabControlPanelBody_А.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanelBody_А.Location = new System.Drawing.Point(0, 22);
            this.superTabControlPanelBody_А.Name = "superTabControlPanelBody_А";
            this.superTabControlPanelBody_А.Padding = new System.Windows.Forms.Padding(1);
            this.superTabControlPanelBody_А.Size = new System.Drawing.Size(1020, 441);
            this.superTabControlPanelBody_А.Style.BackColor1.Color = System.Drawing.Color.White;
            this.superTabControlPanelBody_А.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.superTabControlPanelBody_А.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(211)))), ((int)(((byte)(211)))));
            this.superTabControlPanelBody_А.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.superTabControlPanelBody_А.Style.GradientAngle = 90;
            this.superTabControlPanelBody_А.TabIndex = 1;
            this.superTabControlPanelBody_А.TabItem = this.superTabItemHead_А;
            // 
            // reflectionLabel1_НетКомпонентов
            // 
            this.reflectionLabel1_НетКомпонентов.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.reflectionLabel1_НетКомпонентов.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.reflectionLabel1_НетКомпонентов.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.reflectionLabel1_НетКомпонентов.BackgroundStyle.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.reflectionLabel1_НетКомпонентов.Location = new System.Drawing.Point(194, 60);
            this.reflectionLabel1_НетКомпонентов.Name = "reflectionLabel1_НетКомпонентов";
            this.reflectionLabel1_НетКомпонентов.Size = new System.Drawing.Size(624, 50);
            this.reflectionLabel1_НетКомпонентов.TabIndex = 0;
            this.reflectionLabel1_НетКомпонентов.Text = "<b><font size=\"+6\"><i>Нет </i><font color=\"#B02B2C\">компонентов</font></font></b>" +
                "";
            // 
            // groupPanel1_КритерииАвтоВыбора
            // 
            this.groupPanel1_КритерииАвтоВыбора.BackColor = System.Drawing.Color.White;
            this.groupPanel1_КритерииАвтоВыбора.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1_КритерииАвтоВыбора.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1_КритерииАвтоВыбора.Controls.Add(this.ucNeLogik1);
            this.groupPanel1_КритерииАвтоВыбора.Controls.Add(this.radioButton1_НечеткоеПравило);
            this.groupPanel1_КритерииАвтоВыбора.Controls.Add(this.radioButton1_МаксимальнаяСтоимость);
            this.groupPanel1_КритерииАвтоВыбора.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupPanel1_КритерииАвтоВыбора.Location = new System.Drawing.Point(162, 176);
            this.groupPanel1_КритерииАвтоВыбора.Name = "groupPanel1_КритерииАвтоВыбора";
            this.groupPanel1_КритерииАвтоВыбора.Size = new System.Drawing.Size(857, 264);
            // 
            // 
            // 
            this.groupPanel1_КритерииАвтоВыбора.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1_КритерииАвтоВыбора.Style.BackColorGradientAngle = 90;
            this.groupPanel1_КритерииАвтоВыбора.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1_КритерииАвтоВыбора.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1_КритерииАвтоВыбора.Style.BorderBottomWidth = 1;
            this.groupPanel1_КритерииАвтоВыбора.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1_КритерииАвтоВыбора.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1_КритерииАвтоВыбора.Style.BorderLeftWidth = 1;
            this.groupPanel1_КритерииАвтоВыбора.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1_КритерииАвтоВыбора.Style.BorderRightWidth = 1;
            this.groupPanel1_КритерииАвтоВыбора.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1_КритерииАвтоВыбора.Style.BorderTopWidth = 1;
            this.groupPanel1_КритерииАвтоВыбора.Style.CornerDiameter = 2;
            this.groupPanel1_КритерииАвтоВыбора.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1_КритерииАвтоВыбора.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1_КритерииАвтоВыбора.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1_КритерииАвтоВыбора.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1_КритерииАвтоВыбора.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1_КритерииАвтоВыбора.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1_КритерииАвтоВыбора.TabIndex = 0;
            this.groupPanel1_КритерииАвтоВыбора.Text = "Настройка";
            this.groupPanel1_КритерииАвтоВыбора.Visible = false;
            // 
            // radioButton1_НечеткоеПравило
            // 
            this.radioButton1_НечеткоеПравило.AutoSize = true;
            this.radioButton1_НечеткоеПравило.BackColor = System.Drawing.Color.Transparent;
            this.radioButton1_НечеткоеПравило.Location = new System.Drawing.Point(242, 6);
            this.radioButton1_НечеткоеПравило.Name = "radioButton1_НечеткоеПравило";
            this.radioButton1_НечеткоеПравило.Size = new System.Drawing.Size(186, 17);
            this.radioButton1_НечеткоеПравило.TabIndex = 1;
            this.radioButton1_НечеткоеПравило.TabStop = true;
            this.radioButton1_НечеткоеПравило.Text = "Нечеткий индекс оборудования";
            this.radioButton1_НечеткоеПравило.UseVisualStyleBackColor = false;
            this.radioButton1_НечеткоеПравило.CheckedChanged += new System.EventHandler(this.radioButton1_НечеткоеПравило_CheckedChanged);
            // 
            // radioButton1_МаксимальнаяСтоимость
            // 
            this.radioButton1_МаксимальнаяСтоимость.AutoSize = true;
            this.radioButton1_МаксимальнаяСтоимость.BackColor = System.Drawing.Color.Transparent;
            this.radioButton1_МаксимальнаяСтоимость.Checked = true;
            this.radioButton1_МаксимальнаяСтоимость.Location = new System.Drawing.Point(3, 6);
            this.radioButton1_МаксимальнаяСтоимость.Name = "radioButton1_МаксимальнаяСтоимость";
            this.radioButton1_МаксимальнаяСтоимость.Size = new System.Drawing.Size(233, 17);
            this.radioButton1_МаксимальнаяСтоимость.TabIndex = 0;
            this.radioButton1_МаксимальнаяСтоимость.TabStop = true;
            this.radioButton1_МаксимальнаяСтоимость.Text = "Максимальная стоимость оборудования";
            this.radioButton1_МаксимальнаяСтоимость.UseVisualStyleBackColor = false;
            this.radioButton1_МаксимальнаяСтоимость.CheckedChanged += new System.EventHandler(this.radioButton1_НечеткоеПравило_CheckedChanged);
            // 
            // advTree1
            // 
            this.advTree1.AccessibleRole = System.Windows.Forms.AccessibleRole.Outline;
            this.advTree1.AllowDrop = true;
            this.advTree1.BackColor = System.Drawing.SystemColors.Window;
            // 
            // 
            // 
            this.advTree1.BackgroundStyle.Class = "TreeBorderKey";
            this.advTree1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.advTree1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.advTree1.DragDropNodeCopyEnabled = false;
            this.advTree1.GridLinesColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.advTree1.GridRowLines = true;
            this.advTree1.Location = new System.Drawing.Point(162, 176);
            this.advTree1.MultiNodeDragDropAllowed = false;
            this.advTree1.Name = "advTree1";
            this.advTree1.NodesConnector = this.nodeConnector1;
            this.advTree1.NodeStyle = this.elementStyle1;
            this.advTree1.PathSeparator = ";";
            this.advTree1.Size = new System.Drawing.Size(857, 264);
            this.advTree1.Styles.Add(this.elementStyle1);
            this.advTree1.TabIndex = 2;
            this.advTree1.Text = "advTree1";
            this.advTree1.NodeDoubleClick += new DevComponents.AdvTree.TreeNodeMouseEventHandler(this.advTree1_NodeDoubleClick);
            // 
            // nodeConnector1
            // 
            this.nodeConnector1.LineColor = System.Drawing.SystemColors.ControlText;
            // 
            // elementStyle1
            // 
            this.elementStyle1.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.elementStyle1.Name = "elementStyle1";
            this.elementStyle1.TextColor = System.Drawing.SystemColors.ControlText;
            // 
            // groupPanel_РежимВыбора
            // 
            this.groupPanel_РежимВыбора.BackColor = System.Drawing.Color.White;
            this.groupPanel_РежимВыбора.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel_РежимВыбора.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel_РежимВыбора.Controls.Add(this.itemPanel_СемьЭлементов);
            this.groupPanel_РежимВыбора.Controls.Add(this.switchButton_РучнойАвто);
            this.groupPanel_РежимВыбора.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupPanel_РежимВыбора.Location = new System.Drawing.Point(1, 176);
            this.groupPanel_РежимВыбора.Name = "groupPanel_РежимВыбора";
            this.groupPanel_РежимВыбора.Size = new System.Drawing.Size(161, 264);
            // 
            // 
            // 
            this.groupPanel_РежимВыбора.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel_РежимВыбора.Style.BackColorGradientAngle = 90;
            this.groupPanel_РежимВыбора.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel_РежимВыбора.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel_РежимВыбора.Style.BorderBottomWidth = 1;
            this.groupPanel_РежимВыбора.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel_РежимВыбора.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel_РежимВыбора.Style.BorderLeftWidth = 1;
            this.groupPanel_РежимВыбора.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel_РежимВыбора.Style.BorderRightWidth = 1;
            this.groupPanel_РежимВыбора.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel_РежимВыбора.Style.BorderTopWidth = 1;
            this.groupPanel_РежимВыбора.Style.CornerDiameter = 4;
            this.groupPanel_РежимВыбора.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel_РежимВыбора.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel_РежимВыбора.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel_РежимВыбора.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel_РежимВыбора.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel_РежимВыбора.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel_РежимВыбора.TabIndex = 1;
            this.groupPanel_РежимВыбора.Text = "Режим выбора";
            // 
            // itemPanel_СемьЭлементов
            // 
            // 
            // 
            // 
            this.itemPanel_СемьЭлементов.BackgroundStyle.Class = "ItemPanel";
            this.itemPanel_СемьЭлементов.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemPanel_СемьЭлементов.ContainerControlProcessDialogKey = true;
            this.itemPanel_СемьЭлементов.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemPanel_СемьЭлементов.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem1_Агломератор,
            this.buttonItem2_дробилка,
            this.buttonItem3_Экструдер,
            this.buttonItem4_Контейнер,
            this.buttonItem5_Конвеер,
            this.buttonItem6_Магнит,
            this.buttonItem7_Пескосушилка});
            this.itemPanel_СемьЭлементов.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemPanel_СемьЭлементов.Location = new System.Drawing.Point(0, 23);
            this.itemPanel_СемьЭлементов.Name = "itemPanel_СемьЭлементов";
            this.itemPanel_СемьЭлементов.Size = new System.Drawing.Size(155, 220);
            this.itemPanel_СемьЭлементов.TabIndex = 2;
            this.itemPanel_СемьЭлементов.Text = "itemPanel1";
            // 
            // buttonItem1_Агломератор
            // 
            this.buttonItem1_Агломератор.ImagePaddingHorizontal = 0;
            this.buttonItem1_Агломератор.ImagePaddingVertical = 0;
            this.buttonItem1_Агломератор.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem1_Агломератор.Name = "buttonItem1_Агломератор";
            this.buttonItem1_Агломератор.Tag = "aglomerator";
            this.buttonItem1_Агломератор.Text = "Агломератор";
            this.buttonItem1_Агломератор.Click += new System.EventHandler(this.buttonItem1_7_Click);
            // 
            // buttonItem2_дробилка
            // 
            this.buttonItem2_дробилка.ImagePaddingHorizontal = 0;
            this.buttonItem2_дробилка.ImagePaddingVertical = 0;
            this.buttonItem2_дробилка.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem2_дробилка.Name = "buttonItem2_дробилка";
            this.buttonItem2_дробилка.Tag = "drobilka";
            this.buttonItem2_дробилка.Text = "Дробилка";
            this.buttonItem2_дробилка.Click += new System.EventHandler(this.buttonItem1_7_Click);
            // 
            // buttonItem3_Экструдер
            // 
            this.buttonItem3_Экструдер.ImagePaddingHorizontal = 0;
            this.buttonItem3_Экструдер.ImagePaddingVertical = 0;
            this.buttonItem3_Экструдер.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem3_Экструдер.Name = "buttonItem3_Экструдер";
            this.buttonItem3_Экструдер.Tag = "ekstruder";
            this.buttonItem3_Экструдер.Text = "Экструдер";
            this.buttonItem3_Экструдер.Click += new System.EventHandler(this.buttonItem1_7_Click);
            // 
            // buttonItem4_Контейнер
            // 
            this.buttonItem4_Контейнер.ImagePaddingHorizontal = 0;
            this.buttonItem4_Контейнер.ImagePaddingVertical = 0;
            this.buttonItem4_Контейнер.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem4_Контейнер.Name = "buttonItem4_Контейнер";
            this.buttonItem4_Контейнер.Tag = "konteiner";
            this.buttonItem4_Контейнер.Text = "Контейнер";
            this.buttonItem4_Контейнер.Click += new System.EventHandler(this.buttonItem1_7_Click);
            // 
            // buttonItem5_Конвеер
            // 
            this.buttonItem5_Конвеер.ImagePaddingHorizontal = 0;
            this.buttonItem5_Конвеер.ImagePaddingVertical = 0;
            this.buttonItem5_Конвеер.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem5_Конвеер.Name = "buttonItem5_Конвеер";
            this.buttonItem5_Конвеер.Tag = "konveer";
            this.buttonItem5_Конвеер.Text = "Конвеер";
            this.buttonItem5_Конвеер.Click += new System.EventHandler(this.buttonItem1_7_Click);
            // 
            // buttonItem6_Магнит
            // 
            this.buttonItem6_Магнит.ImagePaddingHorizontal = 0;
            this.buttonItem6_Магнит.ImagePaddingVertical = 0;
            this.buttonItem6_Магнит.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem6_Магнит.Name = "buttonItem6_Магнит";
            this.buttonItem6_Магнит.Tag = "magnit";
            this.buttonItem6_Магнит.Text = "Магнит";
            this.buttonItem6_Магнит.Click += new System.EventHandler(this.buttonItem1_7_Click);
            // 
            // buttonItem7_Пескосушилка
            // 
            this.buttonItem7_Пескосушилка.ImagePaddingHorizontal = 0;
            this.buttonItem7_Пескосушилка.ImagePaddingVertical = 0;
            this.buttonItem7_Пескосушилка.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem7_Пескосушилка.Name = "buttonItem7_Пескосушилка";
            this.buttonItem7_Пескосушилка.Tag = "peskosuwilka";
            this.buttonItem7_Пескосушилка.Text = "Пескосушилка";
            this.buttonItem7_Пескосушилка.Click += new System.EventHandler(this.buttonItem1_7_Click);
            // 
            // switchButton_РучнойАвто
            // 
            // 
            // 
            // 
            this.switchButton_РучнойАвто.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.switchButton_РучнойАвто.Dock = System.Windows.Forms.DockStyle.Top;
            this.switchButton_РучнойАвто.FocusCuesEnabled = false;
            this.switchButton_РучнойАвто.Location = new System.Drawing.Point(0, 0);
            this.switchButton_РучнойАвто.Name = "switchButton_РучнойАвто";
            this.switchButton_РучнойАвто.OffText = "Ручной";
            this.switchButton_РучнойАвто.OnText = "Авто";
            this.switchButton_РучнойАвто.Size = new System.Drawing.Size(155, 23);
            this.switchButton_РучнойАвто.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.switchButton_РучнойАвто.TabIndex = 0;
            this.switchButton_РучнойАвто.ValueChanged += new System.EventHandler(this.switchButton_РучнойАвто_ValueChanged);
            // 
            // flowLayoutPanel_ВизуальныйКонтейнер
            // 
            this.flowLayoutPanel_ВизуальныйКонтейнер.AllowDrop = true;
            this.flowLayoutPanel_ВизуальныйКонтейнер.BackColor = System.Drawing.Color.WhiteSmoke;
            this.flowLayoutPanel_ВизуальныйКонтейнер.ContextMenuStrip = this.contextMenuStrip1;
            this.flowLayoutPanel_ВизуальныйКонтейнер.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel_ВизуальныйКонтейнер.Location = new System.Drawing.Point(1, 1);
            this.flowLayoutPanel_ВизуальныйКонтейнер.Name = "flowLayoutPanel_ВизуальныйКонтейнер";
            this.flowLayoutPanel_ВизуальныйКонтейнер.Size = new System.Drawing.Size(1018, 175);
            this.flowLayoutPanel_ВизуальныйКонтейнер.TabIndex = 0;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.очиститьПолеToolStripMenuItem,
            this.ПечатьtoolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(225, 48);
            // 
            // очиститьПолеToolStripMenuItem
            // 
            this.очиститьПолеToolStripMenuItem.Image = global::MapTech.Properties.Resources.clear;
            this.очиститьПолеToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.очиститьПолеToolStripMenuItem.Name = "очиститьПолеToolStripMenuItem";
            this.очиститьПолеToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.очиститьПолеToolStripMenuItem.Text = "Очистить поле";
            this.очиститьПолеToolStripMenuItem.Click += new System.EventHandler(this.очиститьПолеToolStripMenuItem_Click);
            // 
            // ПечатьtoolStripMenuItem
            // 
            this.ПечатьtoolStripMenuItem.Image = global::MapTech.Properties.Resources.printer;
            this.ПечатьtoolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ПечатьtoolStripMenuItem.Name = "ПечатьtoolStripMenuItem";
            this.ПечатьtoolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.ПечатьtoolStripMenuItem.Text = "Печать маршрутной карты";
            this.ПечатьtoolStripMenuItem.Click += new System.EventHandler(this.ПечатьtoolStripMenuItem_Click);
            // 
            // superTabItemHead_А
            // 
            this.superTabItemHead_А.AttachedControl = this.superTabControlPanelBody_А;
            this.superTabItemHead_А.Name = "superTabItemHead_А";
            this.superTabItemHead_А.Text = "Производственная линия";
            // 
            // superTabControlPanelBody_Б
            // 
            this.superTabControlPanelBody_Б.Controls.Add(this.superTabControl1_АБОТ);
            this.superTabControlPanelBody_Б.Controls.Add(this.panelEx1_Меню);
            this.superTabControlPanelBody_Б.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanelBody_Б.Location = new System.Drawing.Point(0, 22);
            this.superTabControlPanelBody_Б.Name = "superTabControlPanelBody_Б";
            this.superTabControlPanelBody_Б.Padding = new System.Windows.Forms.Padding(1);
            this.superTabControlPanelBody_Б.Size = new System.Drawing.Size(1020, 441);
            this.superTabControlPanelBody_Б.Style.BackColor1.Color = System.Drawing.Color.White;
            this.superTabControlPanelBody_Б.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.superTabControlPanelBody_Б.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(211)))), ((int)(((byte)(211)))));
            this.superTabControlPanelBody_Б.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.superTabControlPanelBody_Б.Style.GradientAngle = 90;
            this.superTabControlPanelBody_Б.TabIndex = 0;
            this.superTabControlPanelBody_Б.TabItem = this.superTabItemHead_Б;
            // 
            // superTabControl1_АБОТ
            // 
            this.superTabControl1_АБОТ.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabControl1_АБОТ.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabControl1_АБОТ.ControlBox.MenuBox.Name = "";
            this.superTabControl1_АБОТ.ControlBox.Name = "";
            this.superTabControl1_АБОТ.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl1_АБОТ.ControlBox.MenuBox,
            this.superTabControl1_АБОТ.ControlBox.CloseBox});
            this.superTabControl1_АБОТ.Controls.Add(this.superTabControlPanel1_ПТМ);
            this.superTabControl1_АБОТ.Controls.Add(this.superTabControlPanel4_Т);
            this.superTabControl1_АБОТ.Controls.Add(this.superTabControlPanel3_О);
            this.superTabControl1_АБОТ.Controls.Add(this.superTabControlPanel2_Б);
            this.superTabControl1_АБОТ.Controls.Add(this.superTabControlPanel1_А);
            this.superTabControl1_АБОТ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControl1_АБОТ.ForeColor = System.Drawing.Color.Black;
            this.superTabControl1_АБОТ.Location = new System.Drawing.Point(39, 1);
            this.superTabControl1_АБОТ.Name = "superTabControl1_АБОТ";
            this.superTabControl1_АБОТ.ReorderTabsEnabled = true;
            this.superTabControl1_АБОТ.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.superTabControl1_АБОТ.SelectedTabIndex = 0;
            this.superTabControl1_АБОТ.Size = new System.Drawing.Size(980, 439);
            this.superTabControl1_АБОТ.TabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.superTabControl1_АБОТ.TabIndex = 2;
            this.superTabControl1_АБОТ.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem1_ПТМ,
            this.superTabItem1_А,
            this.superTabItem2_Б,
            this.superTabItem3_О,
            this.superTabItem4_Т});
            this.superTabControl1_АБОТ.TabsVisible = false;
            this.superTabControl1_АБОТ.TabVerticalSpacing = 0;
            // 
            // superTabControlPanel1_ПТМ
            // 
            this.superTabControlPanel1_ПТМ.AntiAlias = false;
            this.superTabControlPanel1_ПТМ.Controls.Add(this.advTree2_ТаблОпераций);
            this.superTabControlPanel1_ПТМ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1_ПТМ.Location = new System.Drawing.Point(0, 17);
            this.superTabControlPanel1_ПТМ.Name = "superTabControlPanel1_ПТМ";
            this.superTabControlPanel1_ПТМ.Size = new System.Drawing.Size(980, 422);
            this.superTabControlPanel1_ПТМ.TabIndex = 0;
            this.superTabControlPanel1_ПТМ.TabItem = this.superTabItem1_ПТМ;
            // 
            // advTree2_ТаблОпераций
            // 
            this.advTree2_ТаблОпераций.AccessibleRole = System.Windows.Forms.AccessibleRole.Outline;
            this.advTree2_ТаблОпераций.AllowDrop = true;
            this.advTree2_ТаблОпераций.AntiAlias = false;
            this.advTree2_ТаблОпераций.BackColor = System.Drawing.SystemColors.Window;
            // 
            // 
            // 
            this.advTree2_ТаблОпераций.BackgroundStyle.Class = "TreeBorderKey";
            this.advTree2_ТаблОпераций.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.advTree2_ТаблОпераций.BackgroundStyle.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.advTree2_ТаблОпераций.Columns.Add(this.columnHeader1);
            this.advTree2_ТаблОпераций.Columns.Add(this.columnHeader2);
            this.advTree2_ТаблОпераций.Columns.Add(this.columnHeader3);
            this.advTree2_ТаблОпераций.Dock = System.Windows.Forms.DockStyle.Fill;
            this.advTree2_ТаблОпераций.GridRowLines = true;
            this.advTree2_ТаблОпераций.Location = new System.Drawing.Point(0, 0);
            this.advTree2_ТаблОпераций.Name = "advTree2_ТаблОпераций";
            this.advTree2_ТаблОпераций.NodesConnector = this.nodeConnector2;
            this.advTree2_ТаблОпераций.NodeStyle = this.elementStyle2;
            this.advTree2_ТаблОпераций.PathSeparator = ";";
            this.advTree2_ТаблОпераций.Size = new System.Drawing.Size(980, 422);
            this.advTree2_ТаблОпераций.Styles.Add(this.elementStyle2);
            this.advTree2_ТаблОпераций.TabIndex = 0;
            this.advTree2_ТаблОпераций.Text = "advTree2";
            this.advTree2_ТаблОпераций.NodeClick += new DevComponents.AdvTree.TreeNodeMouseEventHandler(this.advTree2_ТаблОпераций_NodeClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Editable = false;
            this.columnHeader1.Name = "columnHeader1";
            this.columnHeader1.SortingEnabled = false;
            this.columnHeader1.Text = "№ОП";
            this.columnHeader1.Tooltip = "Номер операции в последовательности";
            this.columnHeader1.Width.Absolute = 70;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Editable = false;
            this.columnHeader2.Name = "columnHeader2";
            this.columnHeader2.SortingEnabled = false;
            this.columnHeader2.Text = "Название";
            this.columnHeader2.Tooltip = "Наименование операции";
            this.columnHeader2.Width.Absolute = 190;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Editable = false;
            this.columnHeader3.Name = "columnHeader3";
            this.columnHeader3.SortingEnabled = false;
            this.columnHeader3.Text = "Код";
            this.columnHeader3.Tooltip = "Код операции по технологическому классификатору";
            this.columnHeader3.Width.Absolute = 150;
            // 
            // nodeConnector2
            // 
            this.nodeConnector2.LineColor = System.Drawing.SystemColors.ControlText;
            // 
            // elementStyle2
            // 
            this.elementStyle2.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.elementStyle2.Name = "elementStyle2";
            this.elementStyle2.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.elementStyle2.TextColor = System.Drawing.SystemColors.ControlText;
            // 
            // superTabItem1_ПТМ
            // 
            this.superTabItem1_ПТМ.AttachedControl = this.superTabControlPanel1_ПТМ;
            this.superTabItem1_ПТМ.GlobalItem = false;
            this.superTabItem1_ПТМ.Name = "superTabItem1_ПТМ";
            this.superTabItem1_ПТМ.Text = "Проектирование ТМ";
            // 
            // superTabControlPanel4_Т
            // 
            this.superTabControlPanel4_Т.AntiAlias = false;
            this.superTabControlPanel4_Т.Controls.Add(this.ucТехОснастка1);
            this.superTabControlPanel4_Т.Controls.Add(this.label_СтрокаСостояния_Т);
            this.superTabControlPanel4_Т.Controls.Add(this.textBoxX_Т);
            this.superTabControlPanel4_Т.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel4_Т.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel4_Т.Name = "superTabControlPanel4_Т";
            this.superTabControlPanel4_Т.Size = new System.Drawing.Size(980, 439);
            this.superTabControlPanel4_Т.TabIndex = 0;
            this.superTabControlPanel4_Т.TabItem = this.superTabItem4_Т;
            // 
            // label_СтрокаСостояния_Т
            // 
            this.label_СтрокаСостояния_Т.BackColor = System.Drawing.Color.Transparent;
            this.label_СтрокаСостояния_Т.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_СтрокаСостояния_Т.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_СтрокаСостояния_Т.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label_СтрокаСостояния_Т.Location = new System.Drawing.Point(0, 0);
            this.label_СтрокаСостояния_Т.Name = "label_СтрокаСостояния_Т";
            this.label_СтрокаСостояния_Т.Size = new System.Drawing.Size(980, 20);
            this.label_СтрокаСостояния_Т.TabIndex = 8;
            this.label_СтрокаСостояния_Т.Text = "Строка состояний";
            // 
            // textBoxX_Т
            // 
            this.textBoxX_Т.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_Т.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_Т.Border.Class = "TextBoxBorder";
            this.textBoxX_Т.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_Т.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_Т.Location = new System.Drawing.Point(6, 28);
            this.textBoxX_Т.Multiline = true;
            this.textBoxX_Т.Name = "textBoxX_Т";
            this.textBoxX_Т.Size = new System.Drawing.Size(470, 115);
            this.textBoxX_Т.TabIndex = 1;
            this.textBoxX_Т.WatermarkText = "Информация о применяемой при выполнении операции технологической оснастке";
            this.textBoxX_Т.Click += new System.EventHandler(this.textBoxX_Т_Click);
            // 
            // superTabItem4_Т
            // 
            this.superTabItem4_Т.AttachedControl = this.superTabControlPanel4_Т;
            this.superTabItem4_Т.GlobalItem = false;
            this.superTabItem4_Т.Name = "superTabItem4_Т";
            this.superTabItem4_Т.Text = "Т";
            // 
            // superTabControlPanel3_О
            // 
            this.superTabControlPanel3_О.AntiAlias = false;
            this.superTabControlPanel3_О.Controls.Add(this.label_CтрокаСостояний_О);
            this.superTabControlPanel3_О.Controls.Add(this.textBoxX1_O);
            this.superTabControlPanel3_О.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel3_О.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel3_О.Name = "superTabControlPanel3_О";
            this.superTabControlPanel3_О.Size = new System.Drawing.Size(980, 439);
            this.superTabControlPanel3_О.TabIndex = 0;
            this.superTabControlPanel3_О.TabItem = this.superTabItem3_О;
            // 
            // label_CтрокаСостояний_О
            // 
            this.label_CтрокаСостояний_О.BackColor = System.Drawing.Color.Transparent;
            this.label_CтрокаСостояний_О.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_CтрокаСостояний_О.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_CтрокаСостояний_О.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label_CтрокаСостояний_О.Location = new System.Drawing.Point(0, 0);
            this.label_CтрокаСостояний_О.Name = "label_CтрокаСостояний_О";
            this.label_CтрокаСостояний_О.Size = new System.Drawing.Size(980, 20);
            this.label_CтрокаСостояний_О.TabIndex = 7;
            this.label_CтрокаСостояний_О.Text = "Строка состояний";
            // 
            // textBoxX1_O
            // 
            this.textBoxX1_O.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX1_O.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX1_O.Border.Class = "TextBoxBorder";
            this.textBoxX1_O.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX1_O.ForeColor = System.Drawing.Color.Black;
            this.textBoxX1_O.Location = new System.Drawing.Point(6, 28);
            this.textBoxX1_O.Multiline = true;
            this.textBoxX1_O.Name = "textBoxX1_O";
            this.textBoxX1_O.Size = new System.Drawing.Size(963, 115);
            this.textBoxX1_O.TabIndex = 0;
            this.textBoxX1_O.WatermarkText = "Содержание операции (перехода)";
            this.textBoxX1_O.Click += new System.EventHandler(this.textBoxX1_O_Click);
            // 
            // superTabItem3_О
            // 
            this.superTabItem3_О.AttachedControl = this.superTabControlPanel3_О;
            this.superTabItem3_О.GlobalItem = false;
            this.superTabItem3_О.Name = "superTabItem3_О";
            this.superTabItem3_О.Text = "О";
            // 
            // superTabControlPanel2_Б
            // 
            this.superTabControlPanel2_Б.AntiAlias = false;
            this.superTabControlPanel2_Б.Controls.Add(this.label_СтрокаСостояний_Б);
            this.superTabControlPanel2_Б.Controls.Add(this.integerInput_ОП);
            this.superTabControlPanel2_Б.Controls.Add(this.integerInput_ЕН);
            this.superTabControlPanel2_Б.Controls.Add(this.integerInput_КОИД);
            this.superTabControlPanel2_Б.Controls.Add(this.integerInput__КР);
            this.superTabControlPanel2_Б.Controls.Add(this.panel1_ДляНастроекСправо);
            this.superTabControlPanel2_Б.Controls.Add(this.textBoxX_Тшт);
            this.superTabControlPanel2_Б.Controls.Add(this.textBoxX_Тпз);
            this.superTabControlPanel2_Б.Controls.Add(this.textBoxX_Кшт);
            this.superTabControlPanel2_Б.Controls.Add(this.textBoxX_УТ);
            this.superTabControlPanel2_Б.Controls.Add(this.textBoxX_Р);
            this.superTabControlPanel2_Б.Controls.Add(this.textBoxX_Проф);
            this.superTabControlPanel2_Б.Controls.Add(this.textBoxX_СМ);
            this.superTabControlPanel2_Б.Controls.Add(this.textBoxX_Код);
            this.superTabControlPanel2_Б.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel2_Б.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel2_Б.Name = "superTabControlPanel2_Б";
            this.superTabControlPanel2_Б.Size = new System.Drawing.Size(980, 439);
            this.superTabControlPanel2_Б.TabIndex = 0;
            this.superTabControlPanel2_Б.TabItem = this.superTabItem2_Б;
            // 
            // label_СтрокаСостояний_Б
            // 
            this.label_СтрокаСостояний_Б.BackColor = System.Drawing.Color.Transparent;
            this.label_СтрокаСостояний_Б.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_СтрокаСостояний_Б.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_СтрокаСостояний_Б.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label_СтрокаСостояний_Б.Location = new System.Drawing.Point(0, 0);
            this.label_СтрокаСостояний_Б.Name = "label_СтрокаСостояний_Б";
            this.label_СтрокаСостояний_Б.Size = new System.Drawing.Size(509, 20);
            this.label_СтрокаСостояний_Б.TabIndex = 6;
            this.label_СтрокаСостояний_Б.Text = "Строка состояний";
            // 
            // integerInput_ОП
            // 
            this.integerInput_ОП.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.integerInput_ОП.BackgroundStyle.Class = "DateTimeInputBackground";
            this.integerInput_ОП.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.integerInput_ОП.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.integerInput_ОП.Location = new System.Drawing.Point(6, 249);
            this.integerInput_ОП.MaxValue = 1000;
            this.integerInput_ОП.MinValue = 0;
            this.integerInput_ОП.Name = "integerInput_ОП";
            this.integerInput_ОП.ShowUpDown = true;
            this.integerInput_ОП.Size = new System.Drawing.Size(497, 20);
            this.integerInput_ОП.TabIndex = 5;
            this.toolTip1.SetToolTip(this.integerInput_ОП, "Объем производственной партии в штуках");
            this.integerInput_ОП.WatermarkText = "Объем производственной партии в штуках";
            this.integerInput_ОП.Enter += new System.EventHandler(this.integerInput_ОП_Click);
            this.integerInput_ОП.Click += new System.EventHandler(this.integerInput_ОП_Click);
            // 
            // integerInput_ЕН
            // 
            this.integerInput_ЕН.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.integerInput_ЕН.BackgroundStyle.Class = "DateTimeInputBackground";
            this.integerInput_ЕН.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.integerInput_ЕН.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.integerInput_ЕН.Location = new System.Drawing.Point(6, 223);
            this.integerInput_ЕН.MaxValue = 1000;
            this.integerInput_ЕН.MinValue = 0;
            this.integerInput_ЕН.Name = "integerInput_ЕН";
            this.integerInput_ЕН.ShowUpDown = true;
            this.integerInput_ЕН.Size = new System.Drawing.Size(497, 20);
            this.integerInput_ЕН.TabIndex = 5;
            this.toolTip1.SetToolTip(this.integerInput_ЕН, "Единица нормирования, на которую установлена норма расхода материала или норма вр" +
                    "емени");
            this.integerInput_ЕН.WatermarkText = "Единица нормирования, на которую установлена норма расхода материала или норма вр" +
                "емени";
            this.integerInput_ЕН.Enter += new System.EventHandler(this.integerInput_ОП_Click);
            this.integerInput_ЕН.Click += new System.EventHandler(this.integerInput_ОП_Click);
            // 
            // integerInput_КОИД
            // 
            this.integerInput_КОИД.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.integerInput_КОИД.BackgroundStyle.Class = "DateTimeInputBackground";
            this.integerInput_КОИД.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.integerInput_КОИД.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.integerInput_КОИД.Location = new System.Drawing.Point(6, 197);
            this.integerInput_КОИД.MaxValue = 1000;
            this.integerInput_КОИД.MinValue = 0;
            this.integerInput_КОИД.Name = "integerInput_КОИД";
            this.integerInput_КОИД.ShowUpDown = true;
            this.integerInput_КОИД.Size = new System.Drawing.Size(497, 20);
            this.integerInput_КОИД.TabIndex = 5;
            this.toolTip1.SetToolTip(this.integerInput_КОИД, "Объем грузовой единицы - количество деталей в таре");
            this.integerInput_КОИД.WatermarkText = "Объем грузовой единицы - количество деталей в таре";
            this.integerInput_КОИД.Enter += new System.EventHandler(this.integerInput_ОП_Click);
            this.integerInput_КОИД.Click += new System.EventHandler(this.integerInput_ОП_Click);
            // 
            // integerInput__КР
            // 
            this.integerInput__КР.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            // 
            // 
            // 
            this.integerInput__КР.BackgroundStyle.Class = "DateTimeInputBackground";
            this.integerInput__КР.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.integerInput__КР.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.integerInput__КР.Location = new System.Drawing.Point(6, 160);
            this.integerInput__КР.MaxValue = 1000;
            this.integerInput__КР.MinValue = 0;
            this.integerInput__КР.Name = "integerInput__КР";
            this.integerInput__КР.ShowUpDown = true;
            this.integerInput__КР.Size = new System.Drawing.Size(497, 20);
            this.integerInput__КР.TabIndex = 5;
            this.toolTip1.SetToolTip(this.integerInput__КР, "Количество исполнителей, занятых при выполнении операции");
            this.integerInput__КР.WatermarkText = "Количество исполнителей, занятых при выполнении операции";
            this.integerInput__КР.Enter += new System.EventHandler(this.integerInput_ОП_Click);
            this.integerInput__КР.Click += new System.EventHandler(this.integerInput_ОП_Click);
            // 
            // panel1_ДляНастроекСправо
            // 
            this.panel1_ДляНастроекСправо.BackColor = System.Drawing.Color.Transparent;
            this.panel1_ДляНастроекСправо.Controls.Add(this.ucКодУсловийТруда1);
            this.panel1_ДляНастроекСправо.Controls.Add(this.ucРазрядРаботы1);
            this.panel1_ДляНастроекСправо.Controls.Add(this.ucСтепеньМеханизац_2);
            this.panel1_ДляНастроекСправо.Controls.Add(this.ucКодПроф_3);
            this.panel1_ДляНастроекСправо.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1_ДляНастроекСправо.Location = new System.Drawing.Point(509, 0);
            this.panel1_ДляНастроекСправо.Name = "panel1_ДляНастроекСправо";
            this.panel1_ДляНастроекСправо.Size = new System.Drawing.Size(471, 439);
            this.panel1_ДляНастроекСправо.TabIndex = 4;
            // 
            // textBoxX_Тшт
            // 
            this.textBoxX_Тшт.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_Тшт.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_Тшт.Border.Class = "TextBoxBorder";
            this.textBoxX_Тшт.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_Тшт.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_Тшт.Location = new System.Drawing.Point(6, 327);
            this.textBoxX_Тшт.Name = "textBoxX_Тшт";
            this.textBoxX_Тшт.Size = new System.Drawing.Size(497, 20);
            this.textBoxX_Тшт.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxX_Тшт, "Норма штучного времени на операцию");
            this.textBoxX_Тшт.WatermarkText = "Норма штучного времени на операцию";
            this.textBoxX_Тшт.Enter += new System.EventHandler(this.integerInput_ОП_Click);
            this.textBoxX_Тшт.Click += new System.EventHandler(this.integerInput_ОП_Click);
            // 
            // textBoxX_Тпз
            // 
            this.textBoxX_Тпз.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_Тпз.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_Тпз.Border.Class = "TextBoxBorder";
            this.textBoxX_Тпз.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_Тпз.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_Тпз.Location = new System.Drawing.Point(6, 301);
            this.textBoxX_Тпз.Name = "textBoxX_Тпз";
            this.textBoxX_Тпз.Size = new System.Drawing.Size(497, 20);
            this.textBoxX_Тпз.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxX_Тпз, "Норма подготовительно-заключительного времени на операцию");
            this.textBoxX_Тпз.WatermarkText = "Норма подготовительно-заключительного времени на операцию";
            this.textBoxX_Тпз.Enter += new System.EventHandler(this.integerInput_ОП_Click);
            this.textBoxX_Тпз.Click += new System.EventHandler(this.integerInput_ОП_Click);
            // 
            // textBoxX_Кшт
            // 
            this.textBoxX_Кшт.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_Кшт.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_Кшт.Border.Class = "TextBoxBorder";
            this.textBoxX_Кшт.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_Кшт.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_Кшт.Location = new System.Drawing.Point(6, 275);
            this.textBoxX_Кшт.Name = "textBoxX_Кшт";
            this.textBoxX_Кшт.Size = new System.Drawing.Size(497, 20);
            this.textBoxX_Кшт.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxX_Кшт, "Коэффициент штучного времени при многостаночном обслуживании");
            this.textBoxX_Кшт.WatermarkText = "Коэффициент штучного времени при многостаночном обслуживании";
            this.textBoxX_Кшт.Enter += new System.EventHandler(this.integerInput_ОП_Click);
            this.textBoxX_Кшт.Click += new System.EventHandler(this.integerInput_ОП_Click);
            // 
            // textBoxX_УТ
            // 
            this.textBoxX_УТ.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_УТ.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_УТ.Border.Class = "TextBoxBorder";
            this.textBoxX_УТ.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_УТ.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_УТ.Location = new System.Drawing.Point(6, 134);
            this.textBoxX_УТ.Name = "textBoxX_УТ";
            this.textBoxX_УТ.Size = new System.Drawing.Size(497, 20);
            this.textBoxX_УТ.TabIndex = 1;
            this.textBoxX_УТ.Tag = "5";
            this.toolTip1.SetToolTip(this.textBoxX_УТ, "Код условий труда по классификатору ОКПДТР и код вида нормы");
            this.textBoxX_УТ.WatermarkText = "Код условий труда по классификатору ОКПДТР и код вида нормы";
            this.textBoxX_УТ.Leave += new System.EventHandler(this.textBoxX_Проф_Leave);
            this.textBoxX_УТ.Enter += new System.EventHandler(this.textBoxX_Проф_Click);
            this.textBoxX_УТ.Click += new System.EventHandler(this.textBoxX_Проф_Click);
            // 
            // textBoxX_Р
            // 
            this.textBoxX_Р.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_Р.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_Р.Border.Class = "TextBoxBorder";
            this.textBoxX_Р.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_Р.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_Р.Location = new System.Drawing.Point(6, 108);
            this.textBoxX_Р.Name = "textBoxX_Р";
            this.textBoxX_Р.Size = new System.Drawing.Size(497, 20);
            this.textBoxX_Р.TabIndex = 1;
            this.textBoxX_Р.Tag = "4";
            this.toolTip1.SetToolTip(this.textBoxX_Р, "Разряд работы, необходимый для выполнения операции");
            this.textBoxX_Р.WatermarkText = "Разряд работы, необходимый для выполнения операции";
            this.textBoxX_Р.Leave += new System.EventHandler(this.textBoxX_Проф_Leave);
            this.textBoxX_Р.Enter += new System.EventHandler(this.textBoxX_Проф_Click);
            this.textBoxX_Р.Click += new System.EventHandler(this.textBoxX_Проф_Click);
            // 
            // textBoxX_Проф
            // 
            this.textBoxX_Проф.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_Проф.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_Проф.Border.Class = "TextBoxBorder";
            this.textBoxX_Проф.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_Проф.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_Проф.Location = new System.Drawing.Point(6, 82);
            this.textBoxX_Проф.Name = "textBoxX_Проф";
            this.textBoxX_Проф.Size = new System.Drawing.Size(497, 20);
            this.textBoxX_Проф.TabIndex = 1;
            this.textBoxX_Проф.Tag = "3";
            this.toolTip1.SetToolTip(this.textBoxX_Проф, "Код профессии по классификатору ОКПДТР");
            this.textBoxX_Проф.WatermarkText = "Код профессии по классификатору ОКПДТР";
            this.textBoxX_Проф.Leave += new System.EventHandler(this.textBoxX_Проф_Leave);
            this.textBoxX_Проф.Enter += new System.EventHandler(this.textBoxX_Проф_Click);
            this.textBoxX_Проф.Click += new System.EventHandler(this.textBoxX_Проф_Click);
            // 
            // textBoxX_СМ
            // 
            this.textBoxX_СМ.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_СМ.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_СМ.Border.Class = "TextBoxBorder";
            this.textBoxX_СМ.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_СМ.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_СМ.Location = new System.Drawing.Point(6, 56);
            this.textBoxX_СМ.Name = "textBoxX_СМ";
            this.textBoxX_СМ.Size = new System.Drawing.Size(497, 20);
            this.textBoxX_СМ.TabIndex = 1;
            this.textBoxX_СМ.Tag = "2";
            this.toolTip1.SetToolTip(this.textBoxX_СМ, "Степень механизации (код степени механизации)");
            this.textBoxX_СМ.WatermarkText = "Степень механизации (код степени механизации)";
            this.textBoxX_СМ.Leave += new System.EventHandler(this.textBoxX_Проф_Leave);
            this.textBoxX_СМ.Enter += new System.EventHandler(this.textBoxX_Проф_Click);
            this.textBoxX_СМ.Click += new System.EventHandler(this.textBoxX_Проф_Click);
            // 
            // textBoxX_Код
            // 
            this.textBoxX_Код.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_Код.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_Код.Border.Class = "TextBoxBorder";
            this.textBoxX_Код.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_Код.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_Код.Location = new System.Drawing.Point(6, 30);
            this.textBoxX_Код.Name = "textBoxX_Код";
            this.textBoxX_Код.Size = new System.Drawing.Size(497, 20);
            this.textBoxX_Код.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxX_Код, "Код, наименование оборудования");
            this.textBoxX_Код.WatermarkText = "Код, наименование оборудования";
            this.textBoxX_Код.Enter += new System.EventHandler(this.integerInput_ОП_Click);
            this.textBoxX_Код.Click += new System.EventHandler(this.integerInput_ОП_Click);
            // 
            // superTabItem2_Б
            // 
            this.superTabItem2_Б.AttachedControl = this.superTabControlPanel2_Б;
            this.superTabItem2_Б.GlobalItem = false;
            this.superTabItem2_Б.Name = "superTabItem2_Б";
            this.superTabItem2_Б.Text = "Б";
            // 
            // superTabControlPanel1_А
            // 
            this.superTabControlPanel1_А.AntiAlias = false;
            this.superTabControlPanel1_А.Controls.Add(this.textBoxX6_ДокОхранаТруда);
            this.superTabControlPanel1_А.Controls.Add(this.textBoxX_КодОперации);
            this.superTabControlPanel1_А.Controls.Add(this.textBoxX_НОперации);
            this.superTabControlPanel1_А.Controls.Add(this.textBoxX_РМесто);
            this.superTabControlPanel1_А.Controls.Add(this.textBoxX_Участок);
            this.superTabControlPanel1_А.Controls.Add(this.textBoxX_Цех);
            this.superTabControlPanel1_А.Controls.Add(this.label_СтрокаСостояний_А);
            this.superTabControlPanel1_А.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1_А.Location = new System.Drawing.Point(0, 0);
            this.superTabControlPanel1_А.Name = "superTabControlPanel1_А";
            this.superTabControlPanel1_А.Size = new System.Drawing.Size(980, 439);
            this.superTabControlPanel1_А.TabIndex = 1;
            this.superTabControlPanel1_А.TabItem = this.superTabItem1_А;
            // 
            // textBoxX6_ДокОхранаТруда
            // 
            this.textBoxX6_ДокОхранаТруда.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX6_ДокОхранаТруда.Border.Class = "TextBoxBorder";
            this.textBoxX6_ДокОхранаТруда.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX6_ДокОхранаТруда.ButtonCustom.Text = "Выбрать...";
            this.textBoxX6_ДокОхранаТруда.ButtonCustom.Visible = true;
            this.textBoxX6_ДокОхранаТруда.ForeColor = System.Drawing.Color.Black;
            this.textBoxX6_ДокОхранаТруда.Location = new System.Drawing.Point(6, 158);
            this.textBoxX6_ДокОхранаТруда.Name = "textBoxX6_ДокОхранаТруда";
            this.textBoxX6_ДокОхранаТруда.Size = new System.Drawing.Size(499, 20);
            this.textBoxX6_ДокОхранаТруда.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxX6_ДокОхранаТруда, "Обозначение документов, инструкций по охране труда");
            this.textBoxX6_ДокОхранаТруда.WatermarkText = "Обозначение документов, инструкций по охране труда";
            this.textBoxX6_ДокОхранаТруда.Enter += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            this.textBoxX6_ДокОхранаТруда.ButtonCustomClick += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_ButtonCustomClick);
            this.textBoxX6_ДокОхранаТруда.Click += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            // 
            // textBoxX_КодОперации
            // 
            this.textBoxX_КодОперации.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_КодОперации.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_КодОперации.Border.Class = "TextBoxBorder";
            this.textBoxX_КодОперации.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_КодОперации.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_КодОперации.Location = new System.Drawing.Point(6, 132);
            this.textBoxX_КодОперации.Name = "textBoxX_КодОперации";
            this.textBoxX_КодОперации.Size = new System.Drawing.Size(962, 20);
            this.textBoxX_КодОперации.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxX_КодОперации, "Код операции по технологическому классификатору, наименование операции.");
            this.textBoxX_КодОперации.WatermarkText = "Код операции по технологическому классификатору, наименование операции.";
            this.textBoxX_КодОперации.Enter += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            this.textBoxX_КодОперации.Click += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            // 
            // textBoxX_НОперации
            // 
            this.textBoxX_НОперации.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_НОперации.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_НОперации.Border.Class = "TextBoxBorder";
            this.textBoxX_НОперации.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_НОперации.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_НОперации.Location = new System.Drawing.Point(6, 106);
            this.textBoxX_НОперации.Name = "textBoxX_НОперации";
            this.textBoxX_НОперации.Size = new System.Drawing.Size(962, 20);
            this.textBoxX_НОперации.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxX_НОперации, "Номер операции (процесса) в технологической последовательности изготовления или р" +
                    "емонта изделия (включая контроль и перемещение)");
            this.textBoxX_НОперации.WatermarkText = "Номер операции (процесса) в технологической последовательности изготовления или р" +
                "емонта изделия (включая контроль и перемещение)";
            this.textBoxX_НОперации.Enter += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            this.textBoxX_НОперации.Click += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            // 
            // textBoxX_РМесто
            // 
            this.textBoxX_РМесто.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_РМесто.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_РМесто.Border.Class = "TextBoxBorder";
            this.textBoxX_РМесто.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_РМесто.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_РМесто.Location = new System.Drawing.Point(6, 80);
            this.textBoxX_РМесто.Name = "textBoxX_РМесто";
            this.textBoxX_РМесто.Size = new System.Drawing.Size(962, 20);
            this.textBoxX_РМесто.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxX_РМесто, "Номер (код) рабочего места");
            this.textBoxX_РМесто.WatermarkText = "Номер (код) рабочего места";
            this.textBoxX_РМесто.Enter += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            this.textBoxX_РМесто.Click += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            // 
            // textBoxX_Участок
            // 
            this.textBoxX_Участок.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_Участок.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_Участок.Border.Class = "TextBoxBorder";
            this.textBoxX_Участок.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_Участок.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_Участок.Location = new System.Drawing.Point(6, 54);
            this.textBoxX_Участок.Name = "textBoxX_Участок";
            this.textBoxX_Участок.Size = new System.Drawing.Size(962, 20);
            this.textBoxX_Участок.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxX_Участок, "Номер (код) участка, конвейера, поточной линии");
            this.textBoxX_Участок.WatermarkText = "Номер (код) участка, конвейера, поточной линии";
            this.textBoxX_Участок.Enter += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            this.textBoxX_Участок.Click += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            // 
            // textBoxX_Цех
            // 
            this.textBoxX_Цех.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxX_Цех.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX_Цех.Border.Class = "TextBoxBorder";
            this.textBoxX_Цех.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX_Цех.ForeColor = System.Drawing.Color.Black;
            this.textBoxX_Цех.Location = new System.Drawing.Point(6, 28);
            this.textBoxX_Цех.Name = "textBoxX_Цех";
            this.textBoxX_Цех.Size = new System.Drawing.Size(962, 20);
            this.textBoxX_Цех.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxX_Цех, "Номер (код) цеха, в котором выполняется операция");
            this.textBoxX_Цех.WatermarkText = "Номер (код) цеха, в котором выполняется операция";
            this.textBoxX_Цех.Enter += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            this.textBoxX_Цех.Click += new System.EventHandler(this.textBoxX6_ДокОхранаТруда_Click);
            // 
            // label_СтрокаСостояний_А
            // 
            this.label_СтрокаСостояний_А.BackColor = System.Drawing.Color.Transparent;
            this.label_СтрокаСостояний_А.Dock = System.Windows.Forms.DockStyle.Top;
            this.label_СтрокаСостояний_А.Enabled = false;
            this.label_СтрокаСостояний_А.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_СтрокаСостояний_А.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label_СтрокаСостояний_А.Location = new System.Drawing.Point(0, 0);
            this.label_СтрокаСостояний_А.Name = "label_СтрокаСостояний_А";
            this.label_СтрокаСостояний_А.Size = new System.Drawing.Size(980, 20);
            this.label_СтрокаСостояний_А.TabIndex = 3;
            this.label_СтрокаСостояний_А.Text = "Строка состояний";
            // 
            // superTabItem1_А
            // 
            this.superTabItem1_А.AttachedControl = this.superTabControlPanel1_А;
            this.superTabItem1_А.GlobalItem = false;
            this.superTabItem1_А.Name = "superTabItem1_А";
            this.superTabItem1_А.Text = "А";
            // 
            // panelEx1_Меню
            // 
            this.panelEx1_Меню.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx1_Меню.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.panelEx1_Меню.Controls.Add(this.buttonX6_Подтвердить);
            this.panelEx1_Меню.Controls.Add(this.buttonX_ТаблицаОперацийПоказать);
            this.panelEx1_Меню.Controls.Add(this.buttonX2);
            this.panelEx1_Меню.Controls.Add(this.buttonX1_Т);
            this.panelEx1_Меню.Controls.Add(this.buttonX1_О);
            this.panelEx1_Меню.Controls.Add(this.buttonX1_Б);
            this.panelEx1_Меню.Controls.Add(this.buttonX1_А);
            this.panelEx1_Меню.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelEx1_Меню.Location = new System.Drawing.Point(1, 1);
            this.panelEx1_Меню.Name = "panelEx1_Меню";
            this.panelEx1_Меню.Size = new System.Drawing.Size(38, 439);
            this.panelEx1_Меню.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx1_Меню.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelEx1_Меню.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx1_Меню.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx1_Меню.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx1_Меню.Style.GradientAngle = 90;
            this.panelEx1_Меню.TabIndex = 0;
            this.panelEx1_Меню.Text = "Меню";
            // 
            // buttonX6_Подтвердить
            // 
            this.buttonX6_Подтвердить.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX6_Подтвердить.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonX6_Подтвердить.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX6_Подтвердить.FocusCuesEnabled = false;
            this.buttonX6_Подтвердить.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.01F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonX6_Подтвердить.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonX6_Подтвердить.ImageTextSpacing = 40;
            this.buttonX6_Подтвердить.Location = new System.Drawing.Point(3, 413);
            this.buttonX6_Подтвердить.Name = "buttonX6_Подтвердить";
            this.buttonX6_Подтвердить.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2);
            this.buttonX6_Подтвердить.Size = new System.Drawing.Size(32, 23);
            this.buttonX6_Подтвердить.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX6_Подтвердить.Symbol = "";
            this.buttonX6_Подтвердить.TabIndex = 1;
            this.buttonX6_Подтвердить.Text = "";
            this.buttonX6_Подтвердить.TextAlignment = DevComponents.DotNetBar.eButtonTextAlignment.Left;
            this.buttonX6_Подтвердить.Tooltip = "Добавить строки в Маршрутную Карту";
            this.buttonX6_Подтвердить.Click += new System.EventHandler(this.buttonX_АБОТ_Click);
            // 
            // buttonX_ТаблицаОперацийПоказать
            // 
            this.buttonX_ТаблицаОперацийПоказать.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX_ТаблицаОперацийПоказать.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX_ТаблицаОперацийПоказать.FocusCuesEnabled = false;
            this.buttonX_ТаблицаОперацийПоказать.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.01F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonX_ТаблицаОперацийПоказать.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonX_ТаблицаОперацийПоказать.ImageTextSpacing = 40;
            this.buttonX_ТаблицаОперацийПоказать.Location = new System.Drawing.Point(3, 166);
            this.buttonX_ТаблицаОперацийПоказать.Name = "buttonX_ТаблицаОперацийПоказать";
            this.buttonX_ТаблицаОперацийПоказать.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2);
            this.buttonX_ТаблицаОперацийПоказать.Size = new System.Drawing.Size(32, 23);
            this.buttonX_ТаблицаОперацийПоказать.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX_ТаблицаОперацийПоказать.Symbol = "";
            this.buttonX_ТаблицаОперацийПоказать.TabIndex = 1;
            this.buttonX_ТаблицаОперацийПоказать.Text = "";
            this.buttonX_ТаблицаОперацийПоказать.TextAlignment = DevComponents.DotNetBar.eButtonTextAlignment.Left;
            this.buttonX_ТаблицаОперацийПоказать.Tooltip = "Таблица Операций";
            this.buttonX_ТаблицаОперацийПоказать.Click += new System.EventHandler(this.buttonX_АБОТ_Click);
            // 
            // buttonX2
            // 
            this.buttonX2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX2.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX2.FocusCuesEnabled = false;
            this.buttonX2.Location = new System.Drawing.Point(4, 137);
            this.buttonX2.Name = "buttonX2";
            this.buttonX2.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2);
            this.buttonX2.Size = new System.Drawing.Size(32, 23);
            this.buttonX2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX2.TabIndex = 1;
            this.buttonX2.Text = "00";
            this.buttonX2.Tooltip = "Пустая строка";
            this.buttonX2.Click += new System.EventHandler(this.buttonX_АБОТ_Click);
            // 
            // buttonX1_Т
            // 
            this.buttonX1_Т.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1_Т.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1_Т.FocusCuesEnabled = false;
            this.buttonX1_Т.Location = new System.Drawing.Point(4, 107);
            this.buttonX1_Т.Name = "buttonX1_Т";
            this.buttonX1_Т.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2);
            this.buttonX1_Т.Size = new System.Drawing.Size(32, 23);
            this.buttonX1_Т.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1_Т.TabIndex = 1;
            this.buttonX1_Т.Text = "Т";
            this.buttonX1_Т.Tooltip = "Информация о применяемой при выполнении операции технологической оснастке";
            this.buttonX1_Т.Click += new System.EventHandler(this.buttonX_АБОТ_Click);
            // 
            // buttonX1_О
            // 
            this.buttonX1_О.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1_О.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1_О.FocusCuesEnabled = false;
            this.buttonX1_О.Location = new System.Drawing.Point(4, 76);
            this.buttonX1_О.Name = "buttonX1_О";
            this.buttonX1_О.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2);
            this.buttonX1_О.Size = new System.Drawing.Size(32, 23);
            this.buttonX1_О.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1_О.TabIndex = 1;
            this.buttonX1_О.Text = "О";
            this.buttonX1_О.Tooltip = "Содержание операции (перехода)";
            this.buttonX1_О.Click += new System.EventHandler(this.buttonX_АБОТ_Click);
            // 
            // buttonX1_Б
            // 
            this.buttonX1_Б.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1_Б.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1_Б.FocusCuesEnabled = false;
            this.buttonX1_Б.Location = new System.Drawing.Point(4, 45);
            this.buttonX1_Б.Name = "buttonX1_Б";
            this.buttonX1_Б.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2);
            this.buttonX1_Б.Size = new System.Drawing.Size(32, 23);
            this.buttonX1_Б.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1_Б.TabIndex = 1;
            this.buttonX1_Б.Text = "Б";
            this.buttonX1_Б.Tooltip = "Код, наименование оборудования и информация по трудозатратам";
            this.buttonX1_Б.Click += new System.EventHandler(this.buttonX_АБОТ_Click);
            // 
            // buttonX1_А
            // 
            this.buttonX1_А.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1_А.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1_А.FocusCuesEnabled = false;
            this.buttonX1_А.Location = new System.Drawing.Point(4, 14);
            this.buttonX1_А.Name = "buttonX1_А";
            this.buttonX1_А.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2);
            this.buttonX1_А.Size = new System.Drawing.Size(32, 23);
            this.buttonX1_А.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1_А.TabIndex = 1;
            this.buttonX1_А.Text = "А";
            this.buttonX1_А.Tooltip = "Номер цеха, участка, рабочего места, где выполняется операция,<br/> номер операци" +
                "и, код и наименование операции, обозначение документов,<br/> применяемых при вып" +
                "олнении операции";
            this.buttonX1_А.Click += new System.EventHandler(this.buttonX_АБОТ_Click);
            // 
            // superTabItemHead_Б
            // 
            this.superTabItemHead_Б.AttachedControl = this.superTabControlPanelBody_Б;
            this.superTabItemHead_Б.Name = "superTabItemHead_Б";
            this.superTabItemHead_Б.Text = "Проектирование";
            // 
            // superTabControlPanel1_Help
            // 
            this.superTabControlPanel1_Help.Controls.Add(this.buttonX1_NextSlideHelp);
            this.superTabControlPanel1_Help.Controls.Add(this.pageSlider1);
            this.superTabControlPanel1_Help.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1_Help.Location = new System.Drawing.Point(0, 22);
            this.superTabControlPanel1_Help.Name = "superTabControlPanel1_Help";
            this.superTabControlPanel1_Help.Padding = new System.Windows.Forms.Padding(1);
            this.superTabControlPanel1_Help.Size = new System.Drawing.Size(1020, 441);
            this.superTabControlPanel1_Help.Style.BackColor1.Color = System.Drawing.Color.White;
            this.superTabControlPanel1_Help.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.superTabControlPanel1_Help.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(211)))), ((int)(((byte)(211)))));
            this.superTabControlPanel1_Help.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.superTabControlPanel1_Help.Style.GradientAngle = 90;
            this.superTabControlPanel1_Help.TabIndex = 2;
            this.superTabControlPanel1_Help.TabItem = this.superTabItem1_HelpTab;
            // 
            // buttonX1_NextSlideHelp
            // 
            this.buttonX1_NextSlideHelp.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1_NextSlideHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonX1_NextSlideHelp.AntiAlias = true;
            this.buttonX1_NextSlideHelp.BackColor = System.Drawing.Color.Transparent;
            this.buttonX1_NextSlideHelp.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1_NextSlideHelp.FocusCuesEnabled = false;
            this.buttonX1_NextSlideHelp.Location = new System.Drawing.Point(940, 394);
            this.buttonX1_NextSlideHelp.Name = "buttonX1_NextSlideHelp";
            this.buttonX1_NextSlideHelp.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2);
            this.buttonX1_NextSlideHelp.Size = new System.Drawing.Size(24, 23);
            this.buttonX1_NextSlideHelp.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1_NextSlideHelp.Symbol = "";
            this.buttonX1_NextSlideHelp.TabIndex = 1;
            this.buttonX1_NextSlideHelp.Tooltip = "Далее";
            this.buttonX1_NextSlideHelp.Click += new System.EventHandler(this.buttonX1_NextSlideHelp_Click);
            // 
            // pageSlider1
            // 
            this.pageSlider1.AnimationTime = 250;
            this.pageSlider1.BackColor = System.Drawing.Color.White;
            this.pageSlider1.Controls.Add(this.pageSliderPage1_ПроизводственнаяЛиния);
            this.pageSlider1.Controls.Add(this.pageSliderPage2_Проектирование);
            this.pageSlider1.Controls.Add(this.pageSliderPage3_МаршрутнаяКарта);
            this.pageSlider1.Controls.Add(this.pageSliderPage4_Оптимизация);
            this.pageSlider1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pageSlider1.Location = new System.Drawing.Point(1, 1);
            this.pageSlider1.Name = "pageSlider1";
            this.pageSlider1.ScrollBarVisibility = DevComponents.DotNetBar.Controls.eScrollBarVisibility.Hidden;
            this.pageSlider1.SelectedPage = this.pageSliderPage1_ПроизводственнаяЛиния;
            this.pageSlider1.Size = new System.Drawing.Size(1018, 439);
            this.pageSlider1.TabIndex = 0;
            // 
            // pageSliderPage1_ПроизводственнаяЛиния
            // 
            this.pageSliderPage1_ПроизводственнаяЛиния.BackColor = System.Drawing.Color.Transparent;
            this.pageSliderPage1_ПроизводственнаяЛиния.Controls.Add(this.label4);
            this.pageSliderPage1_ПроизводственнаяЛиния.Controls.Add(this.label1);
            this.pageSliderPage1_ПроизводственнаяЛиния.Controls.Add(this.reflectionImage1_Рис1);
            this.pageSliderPage1_ПроизводственнаяЛиния.Location = new System.Drawing.Point(4, 8);
            this.pageSliderPage1_ПроизводственнаяЛиния.Name = "pageSliderPage1_ПроизводственнаяЛиния";
            this.pageSliderPage1_ПроизводственнаяЛиния.Size = new System.Drawing.Size(912, 427);
            this.pageSliderPage1_ПроизводственнаяЛиния.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(707, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(205, 427);
            this.label4.TabIndex = 3;
            this.label4.Text = resources.GetString("label4.Text");
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(112, 405);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Рисунок 1 - Производственная линия";
            // 
            // reflectionImage1_Рис1
            // 
            this.reflectionImage1_Рис1.AntiAlias = false;
            // 
            // 
            // 
            this.reflectionImage1_Рис1.BackgroundStyle.BackgroundImage = global::MapTech.Properties.Resources.FirstPg_Help;
            this.reflectionImage1_Рис1.BackgroundStyle.BackgroundImagePosition = DevComponents.DotNetBar.eStyleBackgroundImage.Zoom;
            this.reflectionImage1_Рис1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.reflectionImage1_Рис1.BackgroundStyle.Description = "Рисунок 1";
            this.reflectionImage1_Рис1.BackgroundStyle.MarginLeft = 2;
            this.reflectionImage1_Рис1.BackgroundStyle.Name = "Рис 1";
            this.reflectionImage1_Рис1.BackgroundStyle.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.reflectionImage1_Рис1.Dock = System.Windows.Forms.DockStyle.Left;
            this.reflectionImage1_Рис1.Location = new System.Drawing.Point(0, 0);
            this.reflectionImage1_Рис1.Name = "reflectionImage1_Рис1";
            this.reflectionImage1_Рис1.ReflectionEnabled = false;
            this.reflectionImage1_Рис1.Size = new System.Drawing.Size(707, 427);
            this.reflectionImage1_Рис1.TabIndex = 0;
            // 
            // pageSliderPage2_Проектирование
            // 
            this.pageSliderPage2_Проектирование.Controls.Add(this.label3);
            this.pageSliderPage2_Проектирование.Controls.Add(this.label2);
            this.pageSliderPage2_Проектирование.Controls.Add(this.reflectionImage1_Рис2);
            this.pageSliderPage2_Проектирование.Location = new System.Drawing.Point(964, 8);
            this.pageSliderPage2_Проектирование.Name = "pageSliderPage2_Проектирование";
            this.pageSliderPage2_Проектирование.Size = new System.Drawing.Size(912, 427);
            this.pageSliderPage2_Проектирование.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(632, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(280, 427);
            this.label3.TabIndex = 3;
            this.label3.Text = resources.GetString("label3.Text");
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(112, 405);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Рисунок 2 - Проектирование";
            // 
            // reflectionImage1_Рис2
            // 
            // 
            // 
            // 
            this.reflectionImage1_Рис2.BackgroundStyle.BackgroundImage = global::MapTech.Properties.Resources.SecndPg_Help;
            this.reflectionImage1_Рис2.BackgroundStyle.BackgroundImagePosition = DevComponents.DotNetBar.eStyleBackgroundImage.Zoom;
            this.reflectionImage1_Рис2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.reflectionImage1_Рис2.BackgroundStyle.MarginRight = 2;
            this.reflectionImage1_Рис2.BackgroundStyle.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.reflectionImage1_Рис2.Dock = System.Windows.Forms.DockStyle.Left;
            this.reflectionImage1_Рис2.Location = new System.Drawing.Point(0, 0);
            this.reflectionImage1_Рис2.Name = "reflectionImage1_Рис2";
            this.reflectionImage1_Рис2.Size = new System.Drawing.Size(632, 427);
            this.reflectionImage1_Рис2.TabIndex = 0;
            // 
            // pageSliderPage3_МаршрутнаяКарта
            // 
            this.pageSliderPage3_МаршрутнаяКарта.Controls.Add(this.label5);
            this.pageSliderPage3_МаршрутнаяКарта.Controls.Add(this.label6);
            this.pageSliderPage3_МаршрутнаяКарта.Controls.Add(this.reflectionImage1_Рис3);
            this.pageSliderPage3_МаршрутнаяКарта.Location = new System.Drawing.Point(1924, 8);
            this.pageSliderPage3_МаршрутнаяКарта.Name = "pageSliderPage3_МаршрутнаяКарта";
            this.pageSliderPage3_МаршрутнаяКарта.Size = new System.Drawing.Size(912, 427);
            this.pageSliderPage3_МаршрутнаяКарта.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(643, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(269, 427);
            this.label5.TabIndex = 0;
            this.label5.Text = resources.GetString("label5.Text");
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(112, 405);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(209, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Рисунок 3 - Таблица Маршрутная Карта";
            // 
            // reflectionImage1_Рис3
            // 
            // 
            // 
            // 
            this.reflectionImage1_Рис3.BackgroundStyle.BackgroundImage = global::MapTech.Properties.Resources.ThirdPg_Help;
            this.reflectionImage1_Рис3.BackgroundStyle.BackgroundImagePosition = DevComponents.DotNetBar.eStyleBackgroundImage.Center;
            this.reflectionImage1_Рис3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.reflectionImage1_Рис3.BackgroundStyle.PaddingRight = 2;
            this.reflectionImage1_Рис3.BackgroundStyle.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.reflectionImage1_Рис3.Dock = System.Windows.Forms.DockStyle.Left;
            this.reflectionImage1_Рис3.Location = new System.Drawing.Point(0, 0);
            this.reflectionImage1_Рис3.Name = "reflectionImage1_Рис3";
            this.reflectionImage1_Рис3.Size = new System.Drawing.Size(643, 427);
            this.reflectionImage1_Рис3.TabIndex = 1;
            // 
            // pageSliderPage4_Оптимизация
            // 
            this.pageSliderPage4_Оптимизация.Controls.Add(this.label8);
            this.pageSliderPage4_Оптимизация.Controls.Add(this.label7);
            this.pageSliderPage4_Оптимизация.Controls.Add(this.reflectionImage1_Рис4);
            this.pageSliderPage4_Оптимизация.Location = new System.Drawing.Point(2884, 8);
            this.pageSliderPage4_Оптимизация.Name = "pageSliderPage4_Оптимизация";
            this.pageSliderPage4_Оптимизация.Size = new System.Drawing.Size(912, 427);
            this.pageSliderPage4_Оптимизация.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Location = new System.Drawing.Point(655, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(257, 427);
            this.label8.TabIndex = 2;
            this.label8.Text = resources.GetString("label8.Text");
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(112, 405);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(182, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Рисунок 4 - Вкладка Оптимизации";
            // 
            // reflectionImage1_Рис4
            // 
            // 
            // 
            // 
            this.reflectionImage1_Рис4.BackgroundStyle.BackgroundImage = global::MapTech.Properties.Resources.ForthPg_Help;
            this.reflectionImage1_Рис4.BackgroundStyle.BackgroundImagePosition = DevComponents.DotNetBar.eStyleBackgroundImage.Center;
            this.reflectionImage1_Рис4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.reflectionImage1_Рис4.BackgroundStyle.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.reflectionImage1_Рис4.Dock = System.Windows.Forms.DockStyle.Left;
            this.reflectionImage1_Рис4.Location = new System.Drawing.Point(0, 0);
            this.reflectionImage1_Рис4.Name = "reflectionImage1_Рис4";
            this.reflectionImage1_Рис4.Size = new System.Drawing.Size(655, 427);
            this.reflectionImage1_Рис4.TabIndex = 0;
            // 
            // superTabItem1_HelpTab
            // 
            this.superTabItem1_HelpTab.AttachedControl = this.superTabControlPanel1_Help;
            this.superTabItem1_HelpTab.Name = "superTabItem1_HelpTab";
            this.superTabItem1_HelpTab.Text = "Справка";
            this.superTabItem1_HelpTab.Visible = false;
            // 
            // superTabControlPanelBody_В
            // 
            this.superTabControlPanelBody_В.Controls.Add(this.reoGridControl_МаршрутнаяКарта);
            this.superTabControlPanelBody_В.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanelBody_В.Location = new System.Drawing.Point(0, 22);
            this.superTabControlPanelBody_В.Name = "superTabControlPanelBody_В";
            this.superTabControlPanelBody_В.Padding = new System.Windows.Forms.Padding(1);
            this.superTabControlPanelBody_В.Size = new System.Drawing.Size(1020, 441);
            this.superTabControlPanelBody_В.Style.BackColor1.Color = System.Drawing.Color.White;
            this.superTabControlPanelBody_В.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.superTabControlPanelBody_В.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(211)))), ((int)(((byte)(211)))));
            this.superTabControlPanelBody_В.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.superTabControlPanelBody_В.Style.GradientAngle = 90;
            this.superTabControlPanelBody_В.TabIndex = 0;
            this.superTabControlPanelBody_В.TabItem = this.superTabItemHead_В;
            // 
            // reoGridControl_МаршрутнаяКарта
            // 
            this.reoGridControl_МаршрутнаяКарта.BackColor = System.Drawing.Color.White;
            this.reoGridControl_МаршрутнаяКарта.ColumnHeaderContextMenuStrip = null;
            this.reoGridControl_МаршрутнаяКарта.ContextMenuStrip = this.contextMenuStrip1;
            this.reoGridControl_МаршрутнаяКарта.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reoGridControl_МаршрутнаяКарта.LeadHeaderContextMenuStrip = null;
            this.reoGridControl_МаршрутнаяКарта.Location = new System.Drawing.Point(1, 1);
            this.reoGridControl_МаршрутнаяКарта.Name = "reoGridControl_МаршрутнаяКарта";
            this.reoGridControl_МаршрутнаяКарта.RowHeaderContextMenuStrip = null;
            this.reoGridControl_МаршрутнаяКарта.Script = null;
            this.reoGridControl_МаршрутнаяКарта.SheetTabContextMenuStrip = null;
            this.reoGridControl_МаршрутнаяКарта.SheetTabNewButtonVisible = false;
            this.reoGridControl_МаршрутнаяКарта.SheetTabVisible = false;
            this.reoGridControl_МаршрутнаяКарта.SheetTabWidth = 60;
            this.reoGridControl_МаршрутнаяКарта.ShowScrollEndSpacing = true;
            this.reoGridControl_МаршрутнаяКарта.Size = new System.Drawing.Size(1018, 439);
            this.reoGridControl_МаршрутнаяКарта.TabIndex = 0;
            this.reoGridControl_МаршрутнаяКарта.Text = "reoGridControl1";
            // 
            // superTabItemHead_В
            // 
            this.superTabItemHead_В.AttachedControl = this.superTabControlPanelBody_В;
            this.superTabItemHead_В.Name = "superTabItemHead_В";
            this.superTabItemHead_В.Text = "Маршрутная карта";
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Подсказка";
            // 
            // linkLabel_Help
            // 
            this.linkLabel_Help.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel_Help.AutoSize = true;
            this.linkLabel_Help.BackColor = System.Drawing.Color.White;
            this.linkLabel_Help.Location = new System.Drawing.Point(948, 2);
            this.linkLabel_Help.Name = "linkLabel_Help";
            this.linkLabel_Help.Size = new System.Drawing.Size(50, 13);
            this.linkLabel_Help.TabIndex = 2;
            this.linkLabel_Help.TabStop = true;
            this.linkLabel_Help.Text = "Справка";
            this.linkLabel_Help.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_Help_LinkClicked);
            // 
            // ucOptimizm1
            // 
            this.ucOptimizm1.BackColor = System.Drawing.Color.Transparent;
            this.ucOptimizm1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucOptimizm1.Location = new System.Drawing.Point(1, 1);
            this.ucOptimizm1.Name = "ucOptimizm1";
            this.ucOptimizm1.SetC_in = 50;
            this.ucOptimizm1.SetM_in = 400;
            this.ucOptimizm1.SetTпck_in = 70;
            this.ucOptimizm1.SetTпла_in = 200;
            this.ucOptimizm1.Size = new System.Drawing.Size(1018, 260);
            this.ucOptimizm1.TabIndex = 0;
            // 
            // ucParametrs1
            // 
            this.ucParametrs1.BackColor = System.Drawing.Color.Transparent;
            this.ucParametrs1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ucParametrs1.Location = new System.Drawing.Point(1, 261);
            this.ucParametrs1.Name = "ucParametrs1";
            this.ucParametrs1.Size = new System.Drawing.Size(1018, 179);
            this.ucParametrs1.TabIndex = 1;
            // 
            // ucNeLogik1
            // 
            this.ucNeLogik1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ucNeLogik1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(178)))), ((int)(((byte)(215)))));
            this.ucNeLogik1.Location = new System.Drawing.Point(2, 26);
            this.ucNeLogik1.Name = "ucNeLogik1";
            this.ucNeLogik1.Size = new System.Drawing.Size(848, 219);
            this.ucNeLogik1.TabIndex = 2;
            this.ucNeLogik1.Visible = false;
            // 
            // ucТехОснастка1
            // 
            this.ucТехОснастка1.BackColor = System.Drawing.Color.Transparent;
            this.ucТехОснастка1.Dock = System.Windows.Forms.DockStyle.Right;
            this.ucТехОснастка1.Location = new System.Drawing.Point(482, 20);
            this.ucТехОснастка1.Name = "ucТехОснастка1";
            this.ucТехОснастка1.Size = new System.Drawing.Size(498, 419);
            this.ucТехОснастка1.TabIndex = 9;
            this.ucТехОснастка1.ТехОснасткаEvent += new TestFile.listEventHandler(this.ucТехОснастка1_ТехОснасткаEvent);
            // 
            // ucКодУсловийТруда1
            // 
            this.ucКодУсловийТруда1.BackColor = System.Drawing.Color.Transparent;
            this.ucКодУсловийТруда1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucКодУсловийТруда1.Location = new System.Drawing.Point(0, 0);
            this.ucКодУсловийТруда1.Name = "ucКодУсловийТруда1";
            this.ucКодУсловийТруда1.Size = new System.Drawing.Size(471, 439);
            this.ucКодУсловийТруда1.TabIndex = 5;
            this.ucКодУсловийТруда1.КодУсловийТруда_Event += new TestFile.rbnEventHandler(this.ucКодУсловийТруда1_КодУсловийТруда_Event);
            // 
            // ucРазрядРаботы1
            // 
            this.ucРазрядРаботы1.BackColor = System.Drawing.Color.Transparent;
            this.ucРазрядРаботы1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucРазрядРаботы1.Location = new System.Drawing.Point(0, 0);
            this.ucРазрядРаботы1.Name = "ucРазрядРаботы1";
            this.ucРазрядРаботы1.Size = new System.Drawing.Size(471, 439);
            this.ucРазрядРаботы1.TabIndex = 4;
            this.ucРазрядРаботы1.РазрядРабот_Event += new TestFile.rbcEventHandler(this.ucРазрядРаботы1_РазрядРабот_Event);
            // 
            // ucСтепеньМеханизац_2
            // 
            this.ucСтепеньМеханизац_2.BackColor = System.Drawing.Color.Transparent;
            this.ucСтепеньМеханизац_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucСтепеньМеханизац_2.Location = new System.Drawing.Point(0, 0);
            this.ucСтепеньМеханизац_2.Name = "ucСтепеньМеханизац_2";
            this.ucСтепеньМеханизац_2.Size = new System.Drawing.Size(471, 439);
            this.ucСтепеньМеханизац_2.TabIndex = 3;
            this.ucСтепеньМеханизац_2.КодСтепеньМеханизацииEvent += new TestFile.rbEventHandler(this.ucСтепеньМеханизац1_КодСтепеньМеханизацииEvent);
            // 
            // ucКодПроф_3
            // 
            this.ucКодПроф_3.BackColor = System.Drawing.Color.Transparent;
            this.ucКодПроф_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucКодПроф_3.Location = new System.Drawing.Point(0, 0);
            this.ucКодПроф_3.Name = "ucКодПроф_3";
            this.ucКодПроф_3.Size = new System.Drawing.Size(471, 439);
            this.ucКодПроф_3.TabIndex = 2;
            this.ucКодПроф_3.ИзмененияВЛинке += new TestFile.chEventHandler(this.ucКодПроф1_ИзмененияВЛинке);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 463);
            this.Controls.Add(this.linkLabel_Help);
            this.Controls.Add(this.superTabControl_КонтейнерВкладок);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "MapTech";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl_КонтейнерВкладок)).EndInit();
            this.superTabControl_КонтейнерВкладок.ResumeLayout(false);
            this.superTabControlPanel1_Оптимизация.ResumeLayout(false);
            this.superTabControlPanelBody_А.ResumeLayout(false);
            this.groupPanel1_КритерииАвтоВыбора.ResumeLayout(false);
            this.groupPanel1_КритерииАвтоВыбора.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.advTree1)).EndInit();
            this.groupPanel_РежимВыбора.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.superTabControlPanelBody_Б.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1_АБОТ)).EndInit();
            this.superTabControl1_АБОТ.ResumeLayout(false);
            this.superTabControlPanel1_ПТМ.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.advTree2_ТаблОпераций)).EndInit();
            this.superTabControlPanel4_Т.ResumeLayout(false);
            this.superTabControlPanel3_О.ResumeLayout(false);
            this.superTabControlPanel2_Б.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.integerInput_ОП)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.integerInput_ЕН)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.integerInput_КОИД)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.integerInput__КР)).EndInit();
            this.panel1_ДляНастроекСправо.ResumeLayout(false);
            this.superTabControlPanel1_А.ResumeLayout(false);
            this.panelEx1_Меню.ResumeLayout(false);
            this.superTabControlPanel1_Help.ResumeLayout(false);
            this.pageSlider1.ResumeLayout(false);
            this.pageSliderPage1_ПроизводственнаяЛиния.ResumeLayout(false);
            this.pageSliderPage1_ПроизводственнаяЛиния.PerformLayout();
            this.pageSliderPage2_Проектирование.ResumeLayout(false);
            this.pageSliderPage2_Проектирование.PerformLayout();
            this.pageSliderPage3_МаршрутнаяКарта.ResumeLayout(false);
            this.pageSliderPage3_МаршрутнаяКарта.PerformLayout();
            this.pageSliderPage4_Оптимизация.ResumeLayout(false);
            this.pageSliderPage4_Оптимизация.PerformLayout();
            this.superTabControlPanelBody_В.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevComponents.DotNetBar.StyleManager styleManager1;
        private DevComponents.DotNetBar.TabControl superTabControl_КонтейнерВкладок;
        private DevComponents.DotNetBar.TabControlPanel superTabControlPanelBody_А;
        private DevComponents.DotNetBar.TabItem superTabItemHead_А;
        private DevComponents.DotNetBar.TabControlPanel superTabControlPanelBody_В;
        private DevComponents.DotNetBar.TabItem superTabItemHead_В;
        private DevComponents.DotNetBar.TabControlPanel superTabControlPanelBody_Б;
        private DevComponents.DotNetBar.TabItem superTabItemHead_Б;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_ВизуальныйКонтейнер;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel_РежимВыбора;
        private DevComponents.DotNetBar.Controls.SwitchButton switchButton_РучнойАвто;
        private DevComponents.DotNetBar.ItemPanel itemPanel_СемьЭлементов;
        private DevComponents.DotNetBar.ButtonItem buttonItem1_Агломератор;
        private DevComponents.DotNetBar.ButtonItem buttonItem2_дробилка;
        private DevComponents.DotNetBar.ButtonItem buttonItem3_Экструдер;
        private DevComponents.DotNetBar.ButtonItem buttonItem4_Контейнер;
        private DevComponents.DotNetBar.ButtonItem buttonItem5_Конвеер;
        private DevComponents.DotNetBar.ButtonItem buttonItem6_Магнит;
        private DevComponents.DotNetBar.ButtonItem buttonItem7_Пескосушилка;
        private DevComponents.AdvTree.AdvTree advTree1;
        private DevComponents.AdvTree.NodeConnector nodeConnector1;
        private DevComponents.DotNetBar.ElementStyle elementStyle1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem очиститьПолеToolStripMenuItem;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1_КритерииАвтоВыбора;
        private System.Windows.Forms.RadioButton radioButton1_НечеткоеПравило;
        private System.Windows.Forms.RadioButton radioButton1_МаксимальнаяСтоимость;
        private Ne4etkaLogika.UCNeLogik ucNeLogik1;
        private unvell.ReoGrid.ReoGridControl reoGridControl_МаршрутнаяКарта;
        private DevComponents.DotNetBar.Controls.ReflectionLabel reflectionLabel1_НетКомпонентов;
        private DevComponents.DotNetBar.PanelEx panelEx1_Меню;
        private DevComponents.DotNetBar.ButtonX buttonX1_А;
        private DevComponents.DotNetBar.ButtonX buttonX1_Т;
        private DevComponents.DotNetBar.ButtonX buttonX1_О;
        private DevComponents.DotNetBar.ButtonX buttonX1_Б;
        private DevComponents.DotNetBar.SuperTabControl superTabControl1_АБОТ;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel1_А;
        private DevComponents.DotNetBar.SuperTabItem superTabItem1_А;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel4_Т;
        private DevComponents.DotNetBar.SuperTabItem superTabItem4_Т;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel3_О;
        private DevComponents.DotNetBar.SuperTabItem superTabItem3_О;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel2_Б;
        private DevComponents.DotNetBar.SuperTabItem superTabItem2_Б;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_Цех;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_КодОперации;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_НОперации;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_РМесто;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_Участок;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX6_ДокОхранаТруда;
        private DevComponents.DotNetBar.ButtonX buttonX2;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_УТ;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_Р;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_Проф;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_СМ;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_Код;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_Тшт;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_Тпз;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_Кшт;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX1_O;
        private DevComponents.DotNetBar.Controls.TextBoxX textBoxX_Т;
        private DevComponents.DotNetBar.TabControlPanel superTabControlPanel1_Оптимизация;
        private DevComponents.DotNetBar.TabItem superTabItem_Оптимизация;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel1_ПТМ;
        private DevComponents.DotNetBar.SuperTabItem superTabItem1_ПТМ;
        private DevComponents.AdvTree.AdvTree advTree2_ТаблОпераций;
        private DevComponents.AdvTree.NodeConnector nodeConnector2;
        private DevComponents.DotNetBar.ElementStyle elementStyle2;
        private TestFile.UCКодПроф ucКодПроф_3;
        private System.Windows.Forms.Panel panel1_ДляНастроекСправо;
        private TestFile.UCСтепеньМеханизац ucСтепеньМеханизац_2;
        private TestFile.UCРазрядРаботы ucРазрядРаботы1;
        private TestFile.UCКодУсловийТруда ucКодУсловийТруда1;
        private DevComponents.Editors.IntegerInput integerInput__КР;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.LinkLabel linkLabel_Help;
        private DevComponents.DotNetBar.TabControlPanel superTabControlPanel1_Help;
        private DevComponents.DotNetBar.TabItem superTabItem1_HelpTab;
        private DevComponents.DotNetBar.Controls.PageSlider pageSlider1;
        private DevComponents.Editors.IntegerInput integerInput_КОИД;
        private DevComponents.Editors.IntegerInput integerInput_ОП;
        private DevComponents.Editors.IntegerInput integerInput_ЕН;
        private System.Windows.Forms.Label label_СтрокаСостояний_А;
        private System.Windows.Forms.Label label_СтрокаСостояний_Б;
        private System.Windows.Forms.Label label_CтрокаСостояний_О;
        private System.Windows.Forms.Label label_СтрокаСостояния_Т;
        private System.Windows.Forms.ToolStripMenuItem ПечатьtoolStripMenuItem;
        private DevComponents.AdvTree.ColumnHeader columnHeader1;
        private DevComponents.AdvTree.ColumnHeader columnHeader2;
        private DevComponents.DotNetBar.ButtonX buttonX_ТаблицаОперацийПоказать;
        private DevComponents.AdvTree.ColumnHeader columnHeader3;
        private DevComponents.DotNetBar.ButtonX buttonX6_Подтвердить;
        private DevComponents.DotNetBar.Controls.PageSliderPage pageSliderPage1_ПроизводственнаяЛиния;
        private DevComponents.DotNetBar.Controls.PageSliderPage pageSliderPage2_Проектирование;
        private DevComponents.DotNetBar.Controls.PageSliderPage pageSliderPage3_МаршрутнаяКарта;
        private DevComponents.DotNetBar.Controls.PageSliderPage pageSliderPage4_Оптимизация;
        private DevComponents.DotNetBar.Controls.ReflectionImage reflectionImage1_Рис1;
        private System.Windows.Forms.Label label1;
        private DevComponents.DotNetBar.Controls.ReflectionImage reflectionImage1_Рис2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private DevComponents.DotNetBar.Controls.ReflectionImage reflectionImage1_Рис3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private DevComponents.DotNetBar.Controls.ReflectionImage reflectionImage1_Рис4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private DevComponents.DotNetBar.ButtonX buttonX1_NextSlideHelp;
        private TestFile.UCТехОснастка ucТехОснастка1;
        private TestFile.UCOptimizm ucOptimizm1;
        private TestFile.UCParametrs ucParametrs1;
        
    }
}

