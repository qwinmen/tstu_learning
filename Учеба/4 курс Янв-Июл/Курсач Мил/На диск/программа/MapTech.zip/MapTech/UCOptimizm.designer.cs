﻿namespace TestFile
{
    partial class UCOptimizm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCOptimizm));
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.linkLabel_ТаоБ = new System.Windows.Forms.LinkLabel();
            this.linkLabel_ТаоА = new System.Windows.Forms.LinkLabel();
            this.linkLabel_С3Краситель = new System.Windows.Forms.LinkLabel();
            this.linkLabel_С2Песок = new System.Windows.Forms.LinkLabel();
            this.linkLabel_ТемперЗона_Б = new System.Windows.Forms.LinkLabel();
            this.linkLabel_ТемперЗона_А = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.linkLabel_Тпесок = new System.Windows.Forms.LinkLabel();
            this.doubleInput_Тпесок = new DevComponents.Editors.DoubleInput();
            this.doubleInput_t0 = new DevComponents.Editors.DoubleInput();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.doubleInput_mвх = new DevComponents.Editors.DoubleInput();
            this.numericUpDown_Свх = new DevComponents.Editors.DoubleInput();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.linkLabel_РезультВремя = new System.Windows.Forms.LinkLabel();
            this.microChartItem1 = new DevComponents.DotNetBar.MicroChart();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_Тпесок)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_t0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_mвх)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Свх)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.label3.Location = new System.Drawing.Point(417, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 10);
            this.label3.TabIndex = 21;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.linkLabel_ТаоБ);
            this.groupBox2.Controls.Add(this.linkLabel_ТаоА);
            this.groupBox2.Controls.Add(this.linkLabel_С3Краситель);
            this.groupBox2.Controls.Add(this.linkLabel_С2Песок);
            this.groupBox2.Controls.Add(this.linkLabel_ТемперЗона_Б);
            this.groupBox2.Controls.Add(this.linkLabel_ТемперЗона_А);
            this.groupBox2.Location = new System.Drawing.Point(496, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(208, 186);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Определить";
            // 
            // linkLabel_ТаоБ
            // 
            this.linkLabel_ТаоБ.AutoSize = true;
            this.linkLabel_ТаоБ.Location = new System.Drawing.Point(6, 150);
            this.linkLabel_ТаоБ.Name = "linkLabel_ТаоБ";
            this.linkLabel_ТаоБ.Size = new System.Drawing.Size(123, 13);
            this.linkLabel_ТаоБ.TabIndex = 0;
            this.linkLabel_ТаоБ.TabStop = true;
            this.linkLabel_ТаоБ.Text = "Время смешения Б, Хч";
            // 
            // linkLabel_ТаоА
            // 
            this.linkLabel_ТаоА.AutoSize = true;
            this.linkLabel_ТаоА.Location = new System.Drawing.Point(6, 128);
            this.linkLabel_ТаоА.Name = "linkLabel_ТаоА";
            this.linkLabel_ТаоА.Size = new System.Drawing.Size(123, 13);
            this.linkLabel_ТаоА.TabIndex = 0;
            this.linkLabel_ТаоА.TabStop = true;
            this.linkLabel_ТаоА.Text = "Время смешения A, Хч";
            // 
            // linkLabel_С3Краситель
            // 
            this.linkLabel_С3Краситель.AutoSize = true;
            this.linkLabel_С3Краситель.Location = new System.Drawing.Point(6, 105);
            this.linkLabel_С3Краситель.Name = "linkLabel_С3Краситель";
            this.linkLabel_С3Краситель.Size = new System.Drawing.Size(97, 13);
            this.linkLabel_С3Краситель.TabIndex = 0;
            this.linkLabel_С3Краситель.TabStop = true;
            this.linkLabel_С3Краситель.Text = "С3 краситель, Х%";
            // 
            // linkLabel_С2Песок
            // 
            this.linkLabel_С2Песок.AutoSize = true;
            this.linkLabel_С2Песок.Location = new System.Drawing.Point(6, 79);
            this.linkLabel_С2Песок.Name = "linkLabel_С2Песок";
            this.linkLabel_С2Песок.Size = new System.Drawing.Size(74, 13);
            this.linkLabel_С2Песок.TabIndex = 0;
            this.linkLabel_С2Песок.TabStop = true;
            this.linkLabel_С2Песок.Text = "С2 песок, Х%";
            // 
            // linkLabel_ТемперЗона_Б
            // 
            this.linkLabel_ТемперЗона_Б.AutoSize = true;
            this.linkLabel_ТемперЗона_Б.Location = new System.Drawing.Point(6, 48);
            this.linkLabel_ТемперЗона_Б.Name = "linkLabel_ТемперЗона_Б";
            this.linkLabel_ТемперЗона_Б.Size = new System.Drawing.Size(137, 13);
            this.linkLabel_ТемперЗона_Б.TabIndex = 0;
            this.linkLabel_ТемперЗона_Б.TabStop = true;
            this.linkLabel_ТемперЗона_Б.Text = "Температура зоны Б, Х*С";
            // 
            // linkLabel_ТемперЗона_А
            // 
            this.linkLabel_ТемперЗона_А.AutoSize = true;
            this.linkLabel_ТемперЗона_А.Location = new System.Drawing.Point(6, 22);
            this.linkLabel_ТемперЗона_А.Name = "linkLabel_ТемперЗона_А";
            this.linkLabel_ТемперЗона_А.Size = new System.Drawing.Size(137, 13);
            this.linkLabel_ТемперЗона_А.TabIndex = 0;
            this.linkLabel_ТемперЗона_А.TabStop = true;
            this.linkLabel_ТемперЗона_А.Text = "Температура зоны А, Х*С";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Coral;
            this.label1.Location = new System.Drawing.Point(177, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 10);
            this.label1.TabIndex = 18;
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.linkLabel6);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.linkLabel5);
            this.panel1.Location = new System.Drawing.Point(212, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(280, 260);
            this.panel1.TabIndex = 17;
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.linkLabel6.Location = new System.Drawing.Point(113, 54);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(90, 13);
            this.linkLabel6.TabIndex = 0;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "С3 краситель, %";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Chartreuse;
            this.label2.Location = new System.Drawing.Point(98, 202);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 9);
            this.label2.TabIndex = 0;
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.linkLabel5.Location = new System.Drawing.Point(29, 11);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(67, 13);
            this.linkLabel5.TabIndex = 0;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "С2 песок, %";
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Location = new System.Drawing.Point(212, 9);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(159, 13);
            this.linkLabel3.TabIndex = 16;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "ТермоСмесительный Агрегат";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Coral;
            this.groupBox1.Controls.Add(this.linkLabel_Тпесок);
            this.groupBox1.Controls.Add(this.doubleInput_Тпесок);
            this.groupBox1.Controls.Add(this.doubleInput_t0);
            this.groupBox1.Controls.Add(this.linkLabel4);
            this.groupBox1.Controls.Add(this.linkLabel2);
            this.groupBox1.Controls.Add(this.doubleInput_mвх);
            this.groupBox1.Controls.Add(this.numericUpDown_Свх);
            this.groupBox1.Controls.Add(this.linkLabel1);
            this.groupBox1.Location = new System.Drawing.Point(9, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(178, 131);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Входные данные";
            // 
            // linkLabel_Тпесок
            // 
            this.linkLabel_Тпесок.AutoSize = true;
            this.linkLabel_Тпесок.Location = new System.Drawing.Point(3, 109);
            this.linkLabel_Тпесок.Name = "linkLabel_Тпесок";
            this.linkLabel_Тпесок.Size = new System.Drawing.Size(63, 13);
            this.linkLabel_Тпесок.TabIndex = 7;
            this.linkLabel_Тпесок.TabStop = true;
            this.linkLabel_Тпесок.Text = "t(песок), *С";
            // 
            // doubleInput_Тпесок
            // 
            // 
            // 
            // 
            this.doubleInput_Тпесок.BackgroundStyle.Class = "DateTimeInputBackground";
            this.doubleInput_Тпесок.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.doubleInput_Тпесок.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.doubleInput_Тпесок.Increment = 1;
            this.doubleInput_Тпесок.Location = new System.Drawing.Point(68, 105);
            this.doubleInput_Тпесок.MaxValue = 100;
            this.doubleInput_Тпесок.MinValue = 10;
            this.doubleInput_Тпесок.Name = "doubleInput_Тпесок";
            this.doubleInput_Тпесок.ShowUpDown = true;
            this.doubleInput_Тпесок.Size = new System.Drawing.Size(94, 20);
            this.doubleInput_Тпесок.TabIndex = 1;
            this.doubleInput_Тпесок.Value = 70;
            this.doubleInput_Тпесок.ValueChanged += new System.EventHandler(this.doubleInput_Тпесок_ValueChanged);
            // 
            // doubleInput_t0
            // 
            // 
            // 
            // 
            this.doubleInput_t0.BackgroundStyle.Class = "DateTimeInputBackground";
            this.doubleInput_t0.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.doubleInput_t0.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.doubleInput_t0.Increment = 1;
            this.doubleInput_t0.Location = new System.Drawing.Point(68, 79);
            this.doubleInput_t0.MinValue = 0;
            this.doubleInput_t0.Name = "doubleInput_t0";
            this.doubleInput_t0.ShowUpDown = true;
            this.doubleInput_t0.Size = new System.Drawing.Size(94, 20);
            this.doubleInput_t0.TabIndex = 6;
            this.doubleInput_t0.Value = 200;
            this.doubleInput_t0.ValueChanged += new System.EventHandler(this.doubleInput_t0_ValueChanged);
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.Location = new System.Drawing.Point(3, 84);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(59, 13);
            this.linkLabel4.TabIndex = 5;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "t(пласт),*C";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(10, 55);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(53, 13);
            this.linkLabel2.TabIndex = 4;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "mвх, кг/ч";
            // 
            // doubleInput_mвх
            // 
            // 
            // 
            // 
            this.doubleInput_mвх.BackgroundStyle.Class = "DateTimeInputBackground";
            this.doubleInput_mвх.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.doubleInput_mвх.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.doubleInput_mвх.Increment = 1;
            this.doubleInput_mвх.Location = new System.Drawing.Point(68, 48);
            this.doubleInput_mвх.MinValue = 0;
            this.doubleInput_mвх.Name = "doubleInput_mвх";
            this.doubleInput_mвх.ShowUpDown = true;
            this.doubleInput_mвх.Size = new System.Drawing.Size(94, 20);
            this.doubleInput_mвх.TabIndex = 3;
            this.doubleInput_mвх.Value = 400;
            this.doubleInput_mвх.ValueChanged += new System.EventHandler(this.doubleInput_mвх_ValueChanged);
            // 
            // numericUpDown_Свх
            // 
            // 
            // 
            // 
            this.numericUpDown_Свх.BackgroundStyle.Class = "DateTimeInputBackground";
            this.numericUpDown_Свх.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.numericUpDown_Свх.ButtonFreeText.Shortcut = DevComponents.DotNetBar.eShortcut.F2;
            this.numericUpDown_Свх.Increment = 1;
            this.numericUpDown_Свх.Location = new System.Drawing.Point(68, 22);
            this.numericUpDown_Свх.MaxValue = 100;
            this.numericUpDown_Свх.MinValue = 0;
            this.numericUpDown_Свх.Name = "numericUpDown_Свх";
            this.numericUpDown_Свх.ShowUpDown = true;
            this.numericUpDown_Свх.Size = new System.Drawing.Size(94, 20);
            this.numericUpDown_Свх.TabIndex = 2;
            this.numericUpDown_Свх.Value = 50;
            this.numericUpDown_Свх.ValueChanged += new System.EventHandler(this.numericUpDown_Свх_ValueChanged);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(10, 22);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(39, 13);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Свх, %";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.groupBox3.Controls.Add(this.linkLabel7);
            this.groupBox3.Controls.Add(this.linkLabel_РезультВремя);
            this.groupBox3.Location = new System.Drawing.Point(496, 217);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(208, 68);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Выход";
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.Location = new System.Drawing.Point(6, 38);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(74, 13);
            this.linkLabel7.TabIndex = 1;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "m(вых), Хкг/ч";
            // 
            // linkLabel_РезультВремя
            // 
            this.linkLabel_РезультВремя.AutoSize = true;
            this.linkLabel_РезультВремя.Location = new System.Drawing.Point(6, 16);
            this.linkLabel_РезультВремя.Name = "linkLabel_РезультВремя";
            this.linkLabel_РезультВремя.Size = new System.Drawing.Size(119, 13);
            this.linkLabel_РезультВремя.TabIndex = 0;
            this.linkLabel_РезультВремя.TabStop = true;
            this.linkLabel_РезультВремя.Text = "Затраченое время, Хч";
            // 
            // microChartItem1
            // 
            this.microChartItem1.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.microChartItem1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.microChartItem1.ChartType = DevComponents.DotNetBar.eMicroChartType.Pie;
            this.microChartItem1.Location = new System.Drawing.Point(9, 162);
            this.microChartItem1.Name = "microChartItem1";
            this.microChartItem1.Size = new System.Drawing.Size(178, 123);
            this.microChartItem1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.microChartItem1.TabIndex = 22;
            this.microChartItem1.Text = "microChart1";
            // 
            // UCOptimizm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.microChartItem1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.linkLabel3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox3);
            this.Name = "UCOptimizm";
            this.Size = new System.Drawing.Size(738, 324);
            this.Load += new System.EventHandler(this.UCOptimizm_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_Тпесок)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_t0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleInput_mвх)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_Свх)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.LinkLabel linkLabel_ТаоБ;
        private System.Windows.Forms.LinkLabel linkLabel_ТаоА;
        private System.Windows.Forms.LinkLabel linkLabel_С3Краситель;
        private System.Windows.Forms.LinkLabel linkLabel_С2Песок;
        private System.Windows.Forms.LinkLabel linkLabel_ТемперЗона_Б;
        private System.Windows.Forms.LinkLabel linkLabel_ТемперЗона_А;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.LinkLabel linkLabel_Тпесок;
        private DevComponents.Editors.DoubleInput doubleInput_Тпесок;
        private DevComponents.Editors.DoubleInput doubleInput_t0;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private DevComponents.Editors.DoubleInput doubleInput_mвх;
        private DevComponents.Editors.DoubleInput numericUpDown_Свх;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.LinkLabel linkLabel_РезультВремя;
        private DevComponents.DotNetBar.MicroChart microChartItem1;

    }
}
