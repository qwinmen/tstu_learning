﻿namespace TestFile
{
    partial class UCParametrs
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton7_Пескосушилка = new System.Windows.Forms.RadioButton();
            this.radioButton4_Контейнер = new System.Windows.Forms.RadioButton();
            this.radioButton6_Магнит = new System.Windows.Forms.RadioButton();
            this.radioButton3_Экструдер = new System.Windows.Forms.RadioButton();
            this.radioButton5_Конвеер = new System.Windows.Forms.RadioButton();
            this.radioButton2_Дробилка = new System.Windows.Forms.RadioButton();
            this.radioButton1_Агломератор = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.radioButton7_Пескосушилка);
            this.groupBox1.Controls.Add(this.radioButton4_Контейнер);
            this.groupBox1.Controls.Add(this.radioButton6_Магнит);
            this.groupBox1.Controls.Add(this.radioButton3_Экструдер);
            this.groupBox1.Controls.Add(this.radioButton5_Конвеер);
            this.groupBox1.Controls.Add(this.radioButton2_Дробилка);
            this.groupBox1.Controls.Add(this.radioButton1_Агломератор);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(559, 69);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Агрегат";
            // 
            // radioButton7_Пескосушилка
            // 
            this.radioButton7_Пескосушилка.AutoSize = true;
            this.radioButton7_Пескосушилка.Location = new System.Drawing.Point(197, 42);
            this.radioButton7_Пескосушилка.Name = "radioButton7_Пескосушилка";
            this.radioButton7_Пескосушилка.Size = new System.Drawing.Size(100, 17);
            this.radioButton7_Пескосушилка.TabIndex = 0;
            this.radioButton7_Пескосушилка.TabStop = true;
            this.radioButton7_Пескосушилка.Tag = "7";
            this.radioButton7_Пескосушилка.Text = "Пескосушилка";
            this.radioButton7_Пескосушилка.UseVisualStyleBackColor = true;
            this.radioButton7_Пескосушилка.CheckedChanged += new System.EventHandler(this.radioButton7_Пескосушилка_CheckedChanged);
            // 
            // radioButton4_Контейнер
            // 
            this.radioButton4_Контейнер.AutoSize = true;
            this.radioButton4_Контейнер.Location = new System.Drawing.Point(305, 19);
            this.radioButton4_Контейнер.Name = "radioButton4_Контейнер";
            this.radioButton4_Контейнер.Size = new System.Drawing.Size(79, 17);
            this.radioButton4_Контейнер.TabIndex = 0;
            this.radioButton4_Контейнер.TabStop = true;
            this.radioButton4_Контейнер.Tag = "4";
            this.radioButton4_Контейнер.Text = "Контейнер";
            this.radioButton4_Контейнер.UseVisualStyleBackColor = true;
            this.radioButton4_Контейнер.CheckedChanged += new System.EventHandler(this.radioButton7_Пескосушилка_CheckedChanged);
            // 
            // radioButton6_Магнит
            // 
            this.radioButton6_Магнит.AutoSize = true;
            this.radioButton6_Магнит.Location = new System.Drawing.Point(97, 42);
            this.radioButton6_Магнит.Name = "radioButton6_Магнит";
            this.radioButton6_Магнит.Size = new System.Drawing.Size(62, 17);
            this.radioButton6_Магнит.TabIndex = 0;
            this.radioButton6_Магнит.TabStop = true;
            this.radioButton6_Магнит.Tag = "6";
            this.radioButton6_Магнит.Text = "Магнит";
            this.radioButton6_Магнит.UseVisualStyleBackColor = true;
            this.radioButton6_Магнит.CheckedChanged += new System.EventHandler(this.radioButton7_Пескосушилка_CheckedChanged);
            // 
            // radioButton3_Экструдер
            // 
            this.radioButton3_Экструдер.AutoSize = true;
            this.radioButton3_Экструдер.Location = new System.Drawing.Point(197, 19);
            this.radioButton3_Экструдер.Name = "radioButton3_Экструдер";
            this.radioButton3_Экструдер.Size = new System.Drawing.Size(78, 17);
            this.radioButton3_Экструдер.TabIndex = 0;
            this.radioButton3_Экструдер.TabStop = true;
            this.radioButton3_Экструдер.Tag = "3";
            this.radioButton3_Экструдер.Text = "Экструдер";
            this.radioButton3_Экструдер.UseVisualStyleBackColor = true;
            this.radioButton3_Экструдер.CheckedChanged += new System.EventHandler(this.radioButton7_Пескосушилка_CheckedChanged);
            // 
            // radioButton5_Конвеер
            // 
            this.radioButton5_Конвеер.AutoSize = true;
            this.radioButton5_Конвеер.Location = new System.Drawing.Point(6, 42);
            this.radioButton5_Конвеер.Name = "radioButton5_Конвеер";
            this.radioButton5_Конвеер.Size = new System.Drawing.Size(68, 17);
            this.radioButton5_Конвеер.TabIndex = 0;
            this.radioButton5_Конвеер.TabStop = true;
            this.radioButton5_Конвеер.Tag = "5";
            this.radioButton5_Конвеер.Text = "Конвеер";
            this.radioButton5_Конвеер.UseVisualStyleBackColor = true;
            this.radioButton5_Конвеер.CheckedChanged += new System.EventHandler(this.radioButton7_Пескосушилка_CheckedChanged);
            // 
            // radioButton2_Дробилка
            // 
            this.radioButton2_Дробилка.AutoSize = true;
            this.radioButton2_Дробилка.Location = new System.Drawing.Point(97, 19);
            this.radioButton2_Дробилка.Name = "radioButton2_Дробилка";
            this.radioButton2_Дробилка.Size = new System.Drawing.Size(76, 17);
            this.radioButton2_Дробилка.TabIndex = 0;
            this.radioButton2_Дробилка.TabStop = true;
            this.radioButton2_Дробилка.Tag = "2";
            this.radioButton2_Дробилка.Text = "Дробилка";
            this.radioButton2_Дробилка.UseVisualStyleBackColor = true;
            this.radioButton2_Дробилка.CheckedChanged += new System.EventHandler(this.radioButton7_Пескосушилка_CheckedChanged);
            // 
            // radioButton1_Агломератор
            // 
            this.radioButton1_Агломератор.AutoSize = true;
            this.radioButton1_Агломератор.Location = new System.Drawing.Point(6, 19);
            this.radioButton1_Агломератор.Name = "radioButton1_Агломератор";
            this.radioButton1_Агломератор.Size = new System.Drawing.Size(92, 17);
            this.radioButton1_Агломератор.TabIndex = 0;
            this.radioButton1_Агломератор.TabStop = true;
            this.radioButton1_Агломератор.Tag = "1";
            this.radioButton1_Агломератор.Text = "Агломератор";
            this.radioButton1_Агломератор.UseVisualStyleBackColor = true;
            this.radioButton1_Агломератор.CheckedChanged += new System.EventHandler(this.radioButton7_Пескосушилка_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Controls.Add(this.linkLabel2);
            this.panel1.Controls.Add(this.linkLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 69);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(559, 148);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Location = new System.Drawing.Point(3, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(553, 78);
            this.label1.TabIndex = 3;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(6, 32);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(550, 24);
            this.flowLayoutPanel1.TabIndex = 2;
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(3, 16);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(133, 13);
            this.linkLabel2.TabIndex = 1;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Возможность улучшений";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(3, 3);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(97, 13);
            this.linkLabel1.TabIndex = 0;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Текущий агрегат:";
            // 
            // UCParametrs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Name = "UCParametrs";
            this.Size = new System.Drawing.Size(559, 217);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton7_Пескосушилка;
        private System.Windows.Forms.RadioButton radioButton4_Контейнер;
        private System.Windows.Forms.RadioButton radioButton6_Магнит;
        private System.Windows.Forms.RadioButton radioButton3_Экструдер;
        private System.Windows.Forms.RadioButton radioButton5_Конвеер;
        private System.Windows.Forms.RadioButton radioButton2_Дробилка;
        private System.Windows.Forms.RadioButton radioButton1_Агломератор;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label1;
    }
}
