// Type: unvell.ReoGrid.WorksheetSettings
// Assembly: unvell.ReoGrid, Version=1.2.1.0, Culture=neutral, PublicKeyToken=0a947d9ccc179105
// Assembly location: C:\Program Files\Microsoft Visual Studio 9.0\VC#\DllAddon\ReoGrid-1.2.1-Minimum\ReoGrid-1.2.1-Release\unvell.ReoGrid.dll

using System;

namespace unvell.ReoGrid
{
    [Flags]
    public enum WorksheetSettings : ulong
    {
        None = 0,
        Edit_Readonly = 1,
        Edit_AutoFormatCell = 2,
        Edit_FriendlyPercentInput = 4,
        Edit_AutoAdjustRowHeight = 8,
        Edit_AllowAdjustRowHeight = 16,
        Edit_AllowAdjustColumnWidth = 32,
        [Obsolete("renamed to Edit_DragSelectionToMoveCells")] Behavior_DragToMoveCells = 64,
        Edit_DragSelectionToMoveCells = Behavior_DragToMoveCells,
        Edit_DragSelectionToFillSerial = 128,
        Edit_Default =
            Edit_DragSelectionToFillSerial | Edit_DragSelectionToMoveCells | Edit_AllowAdjustColumnWidth |
            Edit_AllowAdjustRowHeight | Edit_AutoAdjustRowHeight | Edit_FriendlyPercentInput | Edit_AutoFormatCell,
        Behavior_DoubleClickToFitRowHeight = 256,
        Behavior_DoubleClickToFitColumnWidth = 512,
        Behavior_DoubleClickToResizeHeight = Behavior_DoubleClickToFitColumnWidth | Behavior_DoubleClickToFitRowHeight,
        Behavior_MouseWheelToScroll = 1024,
        Behavior_MouseWheelToZoom = 2048,
        Behavior_ShortcutKeyToZoom = 4096,
        Behavior_AllowUserChangingPageBreaks = 8192,
        Behavior_ScrollToFocusCell = 16384,
        Behavior_Default =
            Behavior_ScrollToFocusCell | Behavior_AllowUserChangingPageBreaks | Behavior_ShortcutKeyToZoom |
            Behavior_MouseWheelToZoom | Behavior_MouseWheelToScroll | Behavior_DoubleClickToResizeHeight,
        View_ShowColumnHeader = 65536,
        View_ShowRowHeader = 131072,
        View_ShowHeaders = View_ShowRowHeader | View_ShowColumnHeader,
        View_ShowHorizontalRuler = 262144,
        View_ShowVerticalRuler = 524288,
        View_ShowRulers = View_ShowVerticalRuler | View_ShowHorizontalRuler,
        [Obsolete("rename to View_ShowGuideLine")] View_ShowGridLine = 1048576,
        View_ShowGuideLine = View_ShowGridLine,
        View_AllowShowRowOutlines = 2097152,
        View_AllowShowColumnOutlines = 4194304,
        View_AllowShowOutlines = View_AllowShowColumnOutlines | View_AllowShowRowOutlines,
        View_ShowHiddenCellLine = 16777216,
        View_AllowCellTextOverflow = 33554432,
        View_ShowPageBreaks = 67108864,
        View_AntialiasDrawing = 134217728,
        View_Default = View_AntialiasDrawing | View_AllowShowOutlines | View_ShowGuideLine | View_ShowHeaders,
        Formula_AutoUpdateReferenceCell = 268435456,
        Formula_Default = Formula_AutoUpdateReferenceCell,
        Default = Formula_Default | View_Default | Behavior_Default | Edit_Default,
    }
}
